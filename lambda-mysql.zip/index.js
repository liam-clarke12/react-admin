const mysql = require('mysql2/promise');

// Use environment variables for sensitive info (set these in Lambda config)
const {
  DB_HOST,
  DB_USER,
  DB_PASSWORD,
  DB_NAME,
} = process.env;

exports.handler = async (event) => {
  let connection;
  try {
    connection = await mysql.createConnection({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASSWORD,
      database: DB_NAME,
      port: 3306,
    });

    // Simple query to test connection
    const [rows] = await connection.execute('SELECT NOW() AS currentTime');
    
    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Connected to MySQL!',
        currentTime: rows[0].currentTime,
      }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Failed to connect to MySQL',
        error: error.message,
      }),
    };
  } finally {
    if (connection) await connection.end();
  }
};
