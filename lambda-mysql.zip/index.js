require("dotenv").config();
const serverless = require("serverless-http");
const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const morgan = require("morgan");

// ... (previous code)

const app = express();

// ✅ Enhanced request logging
app.use(
  morgan(
    ":method :url :status :res[content-length] - :response-time ms\nHeaders: :req[headers]\nBody: :req[body]"
  )
);

// ✅ Body parsing middleware
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

/* =============================================================================
   ✅ FIX A (Recommended): keep a real Pool, create a PromisePool wrapper once
   - pool: callback-style pool (rarely used directly)
   - db: promise wrapper (use this for async/await queries + getConnection)
   ========================================================================== */

// ✅ MySQL connection pool (callback pool)
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: Number(process.env.DB_PORT || 3306),
  waitForConnections: true,
  connectionLimit: 5, // IMPORTANT for Lambda
  queueLimit: 0,
});

// ✅ Promise wrapper (use THIS everywhere for async/await)
const db = pool.promise();

if (typeof db.promise !== "function") {
  db.promise = () => db;
}

// ✅ Test database connection (promise style)
(async () => {
  try {
    const conn = await db.getConnection();
    console.log("DB connected successfully");
    conn.release();
  } catch (err) {
    console.error("DB connection failed:", err);
  }
})();

// ✅ CORS Configuration (THIS IS THE ONE TO KEEP)
app.use(
  cors({
    origin: function (origin, callback) {
      console.log(`CORS Origin Check: ${origin}`);
      const allowedOrigins = [
        "https://master.d2fdrxobxyr2je.amplifyapp.com",
        "http://localhost:3000", // For local development
      ];
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "X-Requested-With",
      "Origin",
      "Accept",
    ],
    credentials: true,
    maxAge: 86400,
    preflightContinue: false,
    optionsSuccessStatus: 204,
  })
);

app.options(/(.*)/, cors()); // Allow preflight requests globally

app.use((req, res, next) => {
  if (typeof req.body === "string") {
    try {
      req.body = JSON.parse(req.body);
    } catch (err) {
      console.error("Error parsing JSON body:", err.message);
    }
  }
  next();
});

// ✅ Use db (PromisePool) here
async function withConn(fn) {
  const conn = await db.getConnection();
  try {
    return await fn(conn);
  } finally {
    conn.release();
  }
}

function addCorsHeaders(res, req) {
  try {
    const FRONTEND_ORIGIN = "https://master.d2fdrxobxyr2je.amplifyapp.com";
    const origin = (req && req.headers && req.headers.origin) || FRONTEND_ORIGIN;

    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader(
      "Access-Control-Allow-Headers",
      "Content-Type, Authorization, X-Requested-With, Origin, Accept"
    );
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, PUT, DELETE, OPTIONS"
    );
  } catch (err) {
    console.warn("addCorsHeaders failed:", err && err.message);
  }
}

const wrapAsync = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

function registerGlobalErrorHandler(app) {
  app.use((err, req, res, next) => {
    // ensure CORS on the error response too
    try { addCorsHeaders(res, req); } catch (e) { /* ignore */ }

    // log stack/traces to CloudWatch for debugging
    console.error('Unhandled error in route:', {
      message: err && err.message,
      stack: err && err.stack,
      route: req && `${req.method} ${req.originalUrl}`,
      body: req && req.body,
      headers: req && req.headers && { origin: req.headers.origin },
    });

    // common error response (do not leak internals in prod)
    const status = (err && err.status) || 500;
    const payload = {
      message: status === 500 ? 'Internal server error' : err.message,
      // include details only if you want them visible in client (optional)
      ...(process.env.NODE_ENV !== 'production' ? { details: err && err.message } : {}),
    };

    try {
      res.status(status).json(payload);
    } catch (sendErr) {
      console.error('Failed to send JSON error response:', sendErr);
      try { res.sendStatus(500); } catch (e) { /* nothing */ }
    }
  });
}

registerGlobalErrorHandler(app);

async function syncIngredientInventoryForUser(userId) {
  const tag = "[syncIngredientInventoryForUser]";
  const conn = await db.promise().getConnection();
  try {
    console.info(`${tag} start for user=${userId}`);
    await conn.beginTransaction();

    // 1) Aggregate active goods_in per ingredient for this user
    const aggSql = `
      SELECT
        ingredient,
        COALESCE(SUM(stockRemaining), 0) AS amount
      FROM goods_in
      WHERE user_id = ? AND deleted_at IS NULL
      GROUP BY ingredient
    `;
    console.info(`${tag} executing aggregation`, { sql: aggSql, params: [userId] });
    const [aggRows] = await conn.execute(aggSql, [userId]);

    // Convert to map for easy lookup
    const ingredientMap = new Map(); // ingredient -> amount
    for (const r of aggRows) {
      const name = r.ingredient;
      const amount = Number(r.amount || 0);
      ingredientMap.set(name, amount);
    }

    // 2) For each ingredient in map, find a representative barcode (earliest expiryDate)
    // We'll also collect unit if goods_in has unit.
    const upsertSql = `
      INSERT INTO ingredient_inventory (ingredient, amount, barcode, unit, user_id)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        amount = VALUES(amount),
        barcode = VALUES(barcode),
        unit = VALUES(unit)
    `;

    // For ingredients that have zero amount (i.e. no active goods), we'll set amount = 0.
    // You may prefer to delete rows with zero amount — adjust below if desired.

    for (const [ingredient, amount] of ingredientMap.entries()) {
      // Attempt to pick the barcode with earliest expiryDate (fallback to any barcode)
      const barcodeSql = `
        SELECT barCode, unit
        FROM goods_in
        WHERE user_id = ? AND ingredient = ? AND deleted_at IS NULL
        ORDER BY expiryDate IS NULL, expiryDate ASC, date ASC
        LIMIT 1
      `;
      const [pickRows] = await conn.execute(barcodeSql, [userId, ingredient]);
      let barcode = null;
      let unit = null;
      if (Array.isArray(pickRows) && pickRows.length > 0) {
        barcode = pickRows[0].barCode || null;
        unit = pickRows[0].unit || null;
      }

      // Upsert to inventory
      console.info(`${tag} upserting ingredient`, { ingredient, amount, barcode, unit });
      await conn.execute(upsertSql, [ingredient, amount, barcode, unit, userId]);
    }

    // 3) OPTIONAL: If you want ingredient_inventory rows for ingredients that no longer exist
    // in goods_in to be removed or zeroed out, handle here. We'll set any not present to amount = 0.
    // Fetch all inventory ingredients for user to find stale rows.
    const [invRows] = await conn.execute(`SELECT ingredient FROM ingredient_inventory WHERE user_id = ?`, [userId]);
    for (const inv of invRows) {
      if (!ingredientMap.has(inv.ingredient)) {
        // Set to 0 and null barcode/unit (or delete if you prefer)
        console.info(`${tag} zeroing stale inventory for`, inv.ingredient);
        await conn.execute(
          `UPDATE ingredient_inventory SET amount = 0, barcode = NULL, unit = NULL WHERE ingredient = ? AND user_id = ?`,
          [inv.ingredient, userId]
        );
        // alternatively: await conn.execute(`DELETE FROM ingredient_inventory WHERE ingredient = ? AND user_id = ?`, [inv.ingredient, userId]);
      }
    }

    await conn.commit();
    console.info(`${tag} committed for user=${userId}`);
    return { success: true };
  } catch (err) {
    try { await conn.rollback(); } catch (e) { console.error("[sync] rollback failed", e); }
    console.error("[sync] error:", err && err.stack ? err.stack : err);
    throw err;
  } finally {
    try { conn.release(); } catch (e) { console.warn("[sync] release failed", e); }
  }
}

app.post("/api/submit", async (req, res) => {
  const {
    date,
    ingredient,
    stockReceived,
    unit, // new unit field (required)
    barCode,
    expiryDate,
    temperature,
    cognito_id,
    invoiceNumber, // optional: camelCase
    invoice_number, // optional: snake_case fallback
    supplier, // optional supplier from frontend
  } = req.body;

  // Set CORS headers explicitly
  res.setHeader(
    "Access-Control-Allow-Origin",
    "https://master.d2fdrxobxyr2je.amplifyapp.com"
  );
  res.setHeader("Access-Control-Allow-Credentials", "true");

  try {
    console.log("Raw request body:", req.body);

    // Normalize invoice value: treat empty string as null
    const invoiceVal = invoiceNumber ?? invoice_number ?? null;
    const invoice_sql_value =
      typeof invoiceVal === "string" && invoiceVal.trim() === ""
        ? null
        : invoiceVal;

    // Normalize supplier value: treat empty string as null (optional)
    const supplierVal = supplier ?? null;
    const supplier_sql_value =
      typeof supplierVal === "string" && supplierVal.trim() === ""
        ? null
        : supplierVal;

    // Validate required fields (invoice & supplier are optional)
    if (
      !date ||
      !ingredient ||
      (stockReceived === undefined || stockReceived === null) ||
      !unit ||
      !barCode ||
      !expiryDate ||
      temperature === undefined ||
      temperature === null ||
      !cognito_id
    ) {
      console.error("❌ Missing fields in request body:", {
        date,
        ingredient,
        stockReceived,
        unit,
        barCode,
        expiryDate,
        temperature,
        cognito_id,
        invoiceVal,
        supplierVal,
      });
      return res.status(400).json({
        error:
          "All required fields are missing or invalid (invoiceNumber and supplier are optional)",
        received: req.body,
      });
    }

    const connection = await db.promise().getConnection();
    try {
      await connection.beginTransaction();

      // Insert into goods_in (including invoice_number & supplier)
      const goodsInQuery = `
        INSERT INTO goods_in
          (date, ingredient, stockReceived, stockRemaining, barCode, expiryDate, temperature, unit, user_id, invoice_number, supplier)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      const [goodsInResult] = await connection.execute(goodsInQuery, [
        date,
        ingredient,
        Number(stockReceived) || 0,
        Number(stockReceived) || 0, // Initial stockRemaining equals stockReceived
        barCode,
        expiryDate,
        temperature,
        unit, // pass unit
        cognito_id,
        invoice_sql_value, // invoice_number (NULL if not provided)
        supplier_sql_value, // supplier (NULL if not provided)
      ]);

      // Update ingredient_inventory (unchanged structure; invoice/supplier are not part of inventory)
      const ingredientInventoryQuery = `
        INSERT INTO ingredient_inventory (ingredient, amount, barcode, unit)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE amount = amount + ?
      `;
      await connection.execute(ingredientInventoryQuery, [
        ingredient,
        Number(stockReceived) || 0,
        barCode,
        unit, // pass unit
        Number(stockReceived) || 0,
      ]);

      await connection.commit();
      res.status(200).json({
        success: true,
        message: "Data saved successfully",
        id: goodsInResult.insertId,
      });
    } catch (err) {
      await connection.rollback();
      console.error("Database error:", {
        message: err.message,
        stack: err.stack,
        sql: err.sql,
        parameters: err.parameters,
      });
      res
        .status(500)
        .json({ success: false, error: "Database operation failed", details: err.message });
    } finally {
      connection.release();
    }
  } catch (err) {
    console.error("Server error:", {
      message: err.message,
      stack: err.stack,
      request: { headers: req.headers, body: req.body },
    });
    res
      .status(500)
      .json({ success: false, error: "Server error", details: err.message });
  }
});

app.post("/api/submit/batch", async (req, res) => {
  const { entries, cognito_id } = req.body;

  // Allow your frontend origin (same as single route)
  res.setHeader(
    "Access-Control-Allow-Origin",
    "https://master.d2fdrxobxyr2je.amplifyapp.com"
  );
  res.setHeader("Access-Control-Allow-Credentials", "true");

  if (!Array.isArray(entries) || entries.length === 0) {
    return res
      .status(400)
      .json({ success: false, error: "entries must be a non-empty array" });
  }
  if (!cognito_id) {
    return res
      .status(400)
      .json({ success: false, error: "cognito_id is required" });
  }

  // Validate entries quickly before DB work (collect errors)
  const invalid = entries
    .map((e, i) => {
      const missing = [];
      if (!e.date) missing.push("date");
      if (!e.ingredient) missing.push("ingredient");
      if (e.stockReceived === undefined || e.stockReceived === null)
        missing.push("stockReceived");
      if (!e.unit) missing.push("unit");
      if (!e.barCode) missing.push("barCode");
      if (!e.expiryDate) missing.push("expiryDate");
      if (e.temperature === undefined || e.temperature === null)
        missing.push("temperature");
      // invoiceNumber & supplier are optional — do not validate them
      return missing.length ? { index: i, missing } : null;
    })
    .filter(Boolean);

  if (invalid.length) {
    return res.status(400).json({
      success: false,
      error: "Validation failed for some entries",
      details: invalid,
    });
  }

  const connection = await db.promise().getConnection();
  try {
    await connection.beginTransaction();

    const insertedIds = [];
    for (const entry of entries) {
      // Normalize numeric stock
      const stock = Number(entry.stockReceived) || 0;

      // Normalize invoice value: treat empty string as null
      const invVal = entry.invoiceNumber ?? entry.invoice_number ?? null;
      const invSql =
        typeof invVal === "string" && invVal.trim() === "" ? null : invVal;

      // Normalize supplier value: treat empty string as null (optional)
      const supplierVal = entry.supplier ?? null;
      const supplierSql =
        typeof supplierVal === "string" && supplierVal.trim() === ""
          ? null
          : supplierVal;

      const goodsInQuery = `
        INSERT INTO goods_in
          (date, ingredient, stockReceived, stockRemaining, barCode, expiryDate, temperature, unit, user_id, invoice_number, supplier)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;
      const [goodsRes] = await connection.execute(goodsInQuery, [
        entry.date,
        entry.ingredient,
        stock,
        stock, // initial remaining
        entry.barCode,
        entry.expiryDate,
        entry.temperature,
        entry.unit,
        cognito_id,
        invSql, // invoice_number (NULL if not provided)
        supplierSql, // supplier (NULL if not provided)
      ]);
      insertedIds.push(goodsRes.insertId);

      // upsert inventory (unchanged)
      const ingredientInventoryQuery = `
        INSERT INTO ingredient_inventory (ingredient, amount, barcode, unit)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE amount = amount + VALUES(amount)
      `;
      await connection.execute(ingredientInventoryQuery, [
        entry.ingredient,
        stock,
        entry.barCode,
        entry.unit,
      ]);
    }

    await connection.commit();
    return res.status(200).json({
      success: true,
      message: `Inserted ${insertedIds.length} entries`,
      insertedIds,
    });
  } catch (err) {
    await connection.rollback();
    console.error("Batch submit DB error:", {
      message: err.message,
      stack: err.stack,
    });
    return res.status(500).json({
      success: false,
      error: "Database error",
      details: err.message,
    });
  } finally {
    connection.release();
  }
});

app.get("/api/ingredients", async (req, res) => {
  try {
    // 🔍 Canary test: make sure the pool is responsive
    db.getConnection((pingErr, conn) => {
      if (pingErr) {
        console.error("[Ingredients] DB ping failed:", pingErr);
      } else {
        console.log("[Ingredients] DB ping OK");
        conn.release();
      }
    });

    // fetch every distinct ingredient name
    const [rows] = await db
      .promise()
      .query(`
        SELECT DISTINCT name
          FROM user_ingredients
        ORDER BY name
      `);

    // return as { id, name } objects
    const ingredients = rows.map(r => ({
      id:   r.name,
      name: r.name,
    }));

    return res.json(ingredients);
  } catch (err) {
    console.error("🔥 /api/ingredients error:", err.stack || err);
    return res
      .status(500)
      .json({ error: err.message || "Unknown server error" });
  }
});

app.get("/api/custom-ingredients", async (req, res) => {
  const userId = req.query.cognito_id;
  if (!userId) {
    return res.status(400).json({ error: "Missing cognito_id query parameter" });
  }

  try {
    const [rows] = await db
      .promise()
      .query(
        `SELECT id, name, created_at
           FROM custom_ingredients
          WHERE user_id = ?
          ORDER BY created_at DESC`,
        [userId]
      );
    res.json(rows);
  } catch (err) {
    console.error("🔥 GET /api/custom-ingredients error:", err);
    res.status(500).json({ error: err.message || "Failed to fetch custom ingredients" });
  }
});

app.post("/api/custom-ingredients", async (req, res) => {
  const { cognito_id: userId, name } = req.body;
  if (!userId) {
    return res.status(400).json({ error: "Missing cognito_id in request body" });
  }
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Missing or empty name in request body" });
  }

  try {
    // Insert new custom ingredient
    await db
      .promise()
      .query(
        `INSERT INTO custom_ingredients (user_id, name)
         VALUES (?, ?)`,
        [userId, name.trim()]
      );

    // Return updated list
    const [rows] = await db
      .promise()
      .query(
        `SELECT id, name, created_at
           FROM custom_ingredients
          WHERE user_id = ?
          ORDER BY created_at DESC`,
        [userId]
      );
    res.json(rows);
  } catch (err) {
    console.error("🔥 POST /api/custom-ingredients error:", err);
    res.status(500).json({ error: err.message || "Failed to add custom ingredient" });
  }
});

// Example root route
app.get('/', (req, res) => {
  res.json({ message: 'Hello from Express + AWS Lambda!' });
});

// Adjusted GET /dev/api/goods-in route to include stage prefix 'dev'
app.get("/api/goods-in", async (req, res) => {
  const { cognito_id } = req.query; // Get cognito_id from query parameters

  if (!cognito_id) {
    return res.status(400).json({ error: "cognito_id is required" });
  }

  try {
    const query = "SELECT * FROM goods_in WHERE user_id = ?";
    const [results] = await db.promise().query(query, [cognito_id]);
    res.json(results);
  } catch (err) {
    console.error("Database error:", err);
    res.status(500).json({ error: "Database error" });
  }
});

// GET only active goods_in rows (soft-delete aware)
app.get("/api/goods-in/active", async (req, res) => {
  const { cognito_id } = req.query;

  if (!cognito_id) {
    return res.status(400).json({ error: "cognito_id is required" });
  }

  try {
    const query = `
      SELECT *
      FROM goods_in
      WHERE user_id = ?
        AND deleted_at IS NULL
      ORDER BY date DESC, id DESC
    `;
    const [results] = await db.promise().query(query, [cognito_id]);
    res.json(results);
  } catch (err) {
    console.error("Database error:", err);
    res.status(500).json({ error: "Database error" });
  }
});

app.post("/api/delete-row", async (req, res) => {
  const { barCode, cognito_id } = req.body;

  if (!barCode || !cognito_id) {
    return res.status(400).json({ error: "barCode and cognito_id are required" });
  }

  try {
    // Ensure the row exists and is not already soft-deleted
    const [existing] = await db
      .promise()
      .query(
        `SELECT id FROM goods_in
         WHERE barCode = ? AND user_id = ? AND deleted_at IS NULL
         LIMIT 1`,
        [barCode, cognito_id]
      );

    if (existing.length === 0) {
      return res
        .status(404)
        .json({ error: "Row not found, not yours, or already deleted" });
    }

    // Soft delete (UTC for consistency)
    const [result] = await db
      .promise()
      .query(
        `UPDATE goods_in
           SET deleted_at = UTC_TIMESTAMP()
         WHERE barCode = ? AND user_id = ? AND deleted_at IS NULL`,
        [barCode, cognito_id]
      );

    return res.json({
      message: "Row soft-deleted successfully",
      barCode,
    });
  } catch (err) {
    console.error("Failed to soft-delete row:", err);
    res.status(500).json({ error: "Failed to soft-delete row" });
  }
});

app.put("/api/goods-in/:barcode", async (req, res) => {
  const startTs = new Date().toISOString();
  const log = (tag, obj) => console.info(`[PUT.goods-in] ${tag}`, typeof obj === "string" ? obj : JSON.stringify(obj));

  const originalPathBarcode = req.params.barcode;
  const {
    date,
    ingredient,
    temperature,
    stockReceived,
    stockRemaining,
    unit,
    expiryDate,
    barCode: newBarCode, // new barcode (optional) supplied in body
    invoiceNumber,       // accept camelCase
    invoice_number,      // accept snake_case
    cognito_id,
  } = req.body || {};

  // normalize invoice field (prefer invoiceNumber, fallback to invoice_number)
  const invoiceVal = invoiceNumber !== undefined ? invoiceNumber : invoice_number;

  log("Request start", { startTs, originalPathBarcode, body: req.body });

  if (!originalPathBarcode) {
    log("Missing path barcode", {});
    return res.status(400).json({ error: "barcode is required in path" });
  }
  if (!cognito_id) {
    log("Missing cognito_id", {});
    return res.status(400).json({ error: "cognito_id is required" });
  }

  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();
    log("Started DB transaction for user", cognito_id);

    // 1) Find the row by the path barcode AND user_id (and not soft-deleted)
    const selectSql = `SELECT * FROM goods_in WHERE barCode = ? AND user_id = ? AND deleted_at IS NULL LIMIT 1`;
    log("Executing", { sql: selectSql, params: [originalPathBarcode, cognito_id] });
    const [rows] = await conn.execute(selectSql, [originalPathBarcode, cognito_id]);

    if (!rows || rows.length === 0) {
      // Diagnostic queries to help CloudWatch debugging
      log("Exact match rows.length", rows ? rows.length : 0);
      const diag1Sql = `SELECT id, barCode, user_id, deleted_at FROM goods_in WHERE TRIM(LOWER(barCode)) = TRIM(LOWER(?)) LIMIT 10`;
      log("Running diagnostic query 1", { sql: diag1Sql, params: [originalPathBarcode] });
      const [diagRows] = await conn.execute(diag1Sql, [originalPathBarcode]);
      log("diagRows.length", diagRows ? diagRows.length : 0);
      const diag2Sql = `SELECT id, barCode, user_id, deleted_at FROM goods_in WHERE barCode LIKE ? LIMIT 10`;
      log("Running diagnostic query 2 (LIKE)", { sql: diag2Sql, params: [`%${originalPathBarcode}%`] });
      const [likeRows] = await conn.execute(diag2Sql, [`%${originalPathBarcode}%`]);
      log("likeRows.length", likeRows ? likeRows.length : 0);

      await conn.rollback();
      return res.status(404).json({
        error: "No matching goods_in row found for that barCode/user",
        debug: {
          message: "No exact match for this user. Nearby barcodes (if any):",
          exactMatches: diagRows || [],
          likeMatches: likeRows || [],
        },
      });
    }

    const existing = rows[0];
    log("Found existing row", { id: existing.id, barCode: existing.barCode, user_id: existing.user_id });

    // If client wants to change barcode, check unique constraint for the same user.
    if (typeof newBarCode === "string" && newBarCode.trim() && newBarCode !== existing.barCode) {
      const checkSql = `SELECT COUNT(*) AS cnt FROM goods_in WHERE barCode = ? AND user_id = ? AND deleted_at IS NULL`;
      log("Checking new barcode uniqueness", { sql: checkSql, params: [newBarCode, cognito_id] });
      const [chk] = await conn.execute(checkSql, [newBarCode, cognito_id]);
      const conflict = (Array.isArray(chk) && chk[0] && chk[0].cnt) ? Number(chk[0].cnt) > 0 : false;
      log("Barcode conflict check", { conflict, chk });

      if (conflict) {
        await conn.rollback();
        return res.status(409).json({ error: "Conflict: new barCode already exists for this user" });
      }
    }

    // Build update set (allow updating barCode & invoiceNumber too)
    const updateCols = [];
    const params = [];

    if (date !== undefined) {
      updateCols.push("date = ?");
      params.push(date);
    }
    if (ingredient !== undefined) {
      updateCols.push("ingredient = ?");
      params.push(ingredient);
    }
    if (temperature !== undefined) {
      updateCols.push("temperature = ?");
      params.push(temperature);
    }
    if (stockReceived !== undefined) {
      updateCols.push("stockReceived = ?");
      params.push(Number(stockReceived));
    }
    if (stockRemaining !== undefined) {
      updateCols.push("stockRemaining = ?");
      params.push(Number(stockRemaining));
    }
    if (unit !== undefined) {
      updateCols.push("unit = ?");
      params.push(unit);
    }
    if (expiryDate !== undefined) {
      updateCols.push("expiryDate = ?");
      params.push(expiryDate);
    }
    // IMPORTANT: support changing the barcode on update
    if (newBarCode !== undefined) {
      updateCols.push("barCode = ?");
      params.push(newBarCode);
    }

    // Support invoice number update (accepts invoiceNumber or invoice_number from body)
    if (invoiceVal !== undefined) {
      updateCols.push("invoice_number = ?");
      params.push(invoiceVal);
    }

    if (updateCols.length === 0) {
      await conn.rollback();
      log("No updatable fields supplied", {});
      return res.status(400).json({ error: "No updatable fields supplied" });
    }

    // append WHERE params
    params.push(originalPathBarcode, cognito_id);

    const updateSql = `UPDATE goods_in SET ${updateCols.join(", ")} WHERE barCode = ? AND user_id = ? AND deleted_at IS NULL`;
    log("Executing update", { sql: updateSql, params });
    const [updateRes] = await conn.execute(updateSql, params);
    log("Update result", updateRes);

    // Recompute inventory for user (function assumed present)
    try {
      log("Calling syncIngredientInventoryForUser", { user: cognito_id });
      await syncIngredientInventoryForUser(cognito_id);
    } catch (syncErr) {
      // non-fatal: log, but proceed to commit
      log("syncIngredientInventoryForUser failed", { error: syncErr && syncErr.message ? syncErr.message : String(syncErr) });
    }

    await conn.commit();
    log("Transaction committed", {});

    // Return updated row (fresh from DB) — ensure we select by whichever barcode is now authoritative
    const lookupBarcode = (newBarCode && String(newBarCode).trim()) ? newBarCode : originalPathBarcode;
    const [updatedRows] = await conn.execute(`SELECT * FROM goods_in WHERE barCode = ? AND user_id = ? LIMIT 1`, [ lookupBarcode, cognito_id ]);
    log("Selected updated row", { updatedRows: (updatedRows && updatedRows[0]) ? { id: updatedRows[0].id, barCode: updatedRows[0].barCode, invoice_number: updatedRows[0].invoice_number } : null });

    return res.json({ success: true, updated: (updatedRows && updatedRows[0]) ? updatedRows[0] : null });
  } catch (err) {
    try { await conn.rollback(); } catch (e) { log("Rollback failed", { err: e && e.message ? e.message : e }); }
    log("Database error (update)", { error: err && err.message ? err.message : String(err), stack: err && err.stack ? err.stack : null });
    return res.status(500).json({ error: "Database error", details: err.message || String(err) });
  } finally {
    try { conn.release(); } catch (e) { log("Conn release failed", { err: e && e.message ? e.message : e }); }
    log("Finished handler", {});
  }
});

const safeTrim = (v) => {
  const s = String(v ?? "").trim();
  return s.length ? s : "";
};

const normalizeNotes = (notes) => {
  const t = String(notes ?? "").trim();
  return t.length ? t : null;
};

// Accepts frontend keys: combined OR recipe_meta OR combined_meta
// Shape we support (flexible):
// {
//   sources: [{ id|recipe_id|source_recipe_id, multiplier? }],
//   extras:  [{ name, quantity, unit }]
// }
const normalizeCombinedMeta = (body) => {
  const raw = body?.combined || body?.recipe_meta || body?.combined_meta || null;
  if (!raw || typeof raw !== "object") return null;

  const sourcesRaw =
    raw.sources || raw.source_recipes || raw.sourceRecipes || raw.recipes || [];
  const extrasRaw =
    raw.extras || raw.extra_ingredients || raw.extraIngredients || [];

  const sources = Array.isArray(sourcesRaw)
    ? sourcesRaw
        .filter(Boolean)
        .map((s) => {
          const id = s.id ?? s.recipe_id ?? s.recipeId ?? s.source_recipe_id ?? null;
          const mult = s.multiplier ?? s.mult ?? 1;
          return {
            source_recipe_id: id != null ? Number(id) : null,
            multiplier:
              mult === "" || mult == null || Number.isNaN(Number(mult))
                ? 1.0
                : Number(mult),
          };
        })
        .filter((s) => Number.isFinite(s.source_recipe_id))
    : [];

  const extras = Array.isArray(extrasRaw)
    ? extrasRaw
        .filter(Boolean)
        .map((i) => ({
          name: safeTrim(i.name ?? i.ingredient ?? i.ingredient_name),
          quantity:
            i.quantity === "" || i.quantity == null || Number.isNaN(Number(i.quantity))
              ? 0
              : Number(i.quantity),
          unit: safeTrim(i.unit ?? i.uom),
        }))
        .filter((x) => x.name)
    : [];

  if (!sources.length && !extras.length) return null;
  return { sources, extras };
};

// Builds combined meta for frontend drawer from recipe_components + recipe_ingredients
// - sources: each source recipe with its own (scaled) ingredient list
// - extras: attempt to infer "extra" by subtracting scaled source totals from combined totals
const buildCombinedMetaFromDb = async (conn, combinedRecipeId, userId) => {
  // fetch recipe_components
  const [compRows] = await conn.execute(
    `
    SELECT combined_recipe_id, source_recipe_id, multiplier, user_id, created_at
    FROM recipe_components
    WHERE combined_recipe_id = ? AND user_id = ?
    ORDER BY created_at ASC, source_recipe_id ASC
    `,
    [combinedRecipeId, userId]
  );

  if (!compRows || compRows.length === 0) return null;

  // fetch each source recipe + ingredients
  const sourceIds = compRows.map((r) => r.source_recipe_id);
  const multMap = new Map(compRows.map((r) => [Number(r.source_recipe_id), Number(r.multiplier)]));

  // source recipe meta
  const [srcMeta] = await conn.execute(
    `
    SELECT id, recipe_name, units_per_batch
    FROM recipes
    WHERE user_id = ? AND id IN (${sourceIds.map(() => "?").join(",")})
    `,
    [userId, ...sourceIds]
  );

  // source ingredients
  const [srcIngRows] = await conn.execute(
    `
    SELECT
      r.id AS recipe_id,
      r.recipe_name,
      r.units_per_batch,
      i.ingredient_name,
      ri.quantity,
      IFNULL(ri.unit,'') AS unit
    FROM recipes r
    JOIN recipe_ingredients ri
      ON ri.recipe_id = r.id AND ri.user_id = r.user_id
    JOIN ingredients i
      ON i.id = ri.ingredient_id AND i.user_id = r.user_id
    WHERE r.user_id = ?
      AND r.id IN (${sourceIds.map(() => "?").join(",")})
    ORDER BY r.id ASC, ri.id ASC
    `,
    [userId, ...sourceIds]
  );

  // combined recipe ingredients (for extras inference)
  const [combinedIngRows] = await conn.execute(
    `
    SELECT
      i.ingredient_name,
      ri.quantity,
      IFNULL(ri.unit,'') AS unit
    FROM recipe_ingredients ri
    JOIN ingredients i
      ON i.id = ri.ingredient_id AND i.user_id = ri.user_id
    WHERE ri.recipe_id = ? AND ri.user_id = ?
    ORDER BY ri.id ASC
    `,
    [combinedRecipeId, userId]
  );

  // group source rows
  const srcById = new Map();
  for (const m of srcMeta || []) {
    srcById.set(Number(m.id), {
      id: Number(m.id),
      name: m.recipe_name,
      unitsPerBatch: m.units_per_batch,
      ingredients: [],
    });
  }

  for (const row of srcIngRows || []) {
    const rid = Number(row.recipe_id);
    if (!srcById.has(rid)) {
      srcById.set(rid, {
        id: rid,
        name: row.recipe_name,
        unitsPerBatch: row.units_per_batch,
        ingredients: [],
      });
    }
    const multiplier = multMap.get(rid) ?? 1;
    srcById.get(rid).ingredients.push({
      name: row.ingredient_name,
      quantity: Number(row.quantity ?? 0) * Number(multiplier),
      unit: row.unit ?? "",
    });
  }

  // calculate inferred extras
  // totals from combined
  const combinedTotals = new Map(); // key name::unit => qty
  for (const r of combinedIngRows || []) {
    const name = safeTrim(r.ingredient_name);
    const unit = safeTrim(r.unit);
    const key = `${name}::${unit}`;
    const prev = combinedTotals.get(key) || 0;
    combinedTotals.set(key, prev + Number(r.quantity ?? 0));
  }

  // totals from sources (scaled)
  const sourceTotals = new Map();
  for (const src of srcById.values()) {
    for (const ing of src.ingredients || []) {
      const name = safeTrim(ing.name);
      const unit = safeTrim(ing.unit);
      const key = `${name}::${unit}`;
      const prev = sourceTotals.get(key) || 0;
      sourceTotals.set(key, prev + Number(ing.quantity ?? 0));
    }
  }

  const EPS = 1e-6;
  const extras = [];
  for (const [key, combinedQty] of combinedTotals.entries()) {
    const srcQty = sourceTotals.get(key) || 0;
    const diff = Number(combinedQty) - Number(srcQty);
    if (diff > EPS) {
      const [name, unit] = key.split("::");
      extras.push({ name, unit: unit ?? "", quantity: diff });
    }
  }

  const sources = Array.from(srcById.values()).filter((s) => (s.ingredients || []).length);

  return { sources, extras };
};

// ==============================
// POST /api/add-recipe (UPDATED: supports combined recipes + recipe_components + is_combined)
// ==============================
app.post("/api/add-recipe", async (req, res) => {
  console.log("Received request body:", req.body);

  const {
    recipe,
    upb,
    notes,
    ingredients,
    quantities,
    units,
    cognito_id,
    combined, // optional
    recipe_meta, // optional
    combined_meta, // optional
  } = req.body;

  const combinedMeta = normalizeCombinedMeta({ combined, recipe_meta, combined_meta });

  // Basic validation (kept strict)
  if (
    !recipe ||
    upb === undefined ||
    upb === null ||
    !cognito_id ||
    !Array.isArray(ingredients) ||
    !Array.isArray(quantities) ||
    !Array.isArray(units) ||
    ingredients.length !== quantities.length ||
    ingredients.length !== units.length
  ) {
    console.error("Invalid input data:", req.body);
    return res.status(400).json({ error: "Invalid input data" });
  }

  const connection = await db.promise().getConnection();
  try {
    await connection.beginTransaction();
    console.log("Transaction started");

    const isCombined = combinedMeta && (combinedMeta.sources?.length || combinedMeta.extras?.length) ? 1 : 0;

    // Insert into recipes (now includes notes + is_combined)
    const [recipeResult] = await connection.execute(
      `INSERT INTO recipes (recipe_name, units_per_batch, notes, user_id, is_combined)
       VALUES (?, ?, ?, ?, ?)`,
      [recipe, upb, normalizeNotes(notes), cognito_id, isCombined]
    );

    const recipeId = recipeResult.insertId;
    console.log("Inserted recipe with ID:", recipeId);

    // If combined: store recipe_components
    if (isCombined) {
      // clear just-in-case (should be empty on create)
      await connection.execute(
        `DELETE FROM recipe_components WHERE combined_recipe_id = ? AND user_id = ?`,
        [recipeId, cognito_id]
      );

      const sources = combinedMeta?.sources || [];
      for (const s of sources) {
        // sanity: source recipe must belong to same user
        const [check] = await connection.execute(
          `SELECT id FROM recipes WHERE id = ? AND user_id = ? LIMIT 1`,
          [s.source_recipe_id, cognito_id]
        );
        if (!check || check.length === 0) {
          console.warn(
            `[add-recipe] skipping source_recipe_id=${s.source_recipe_id} (not owned by user)`
          );
          continue;
        }

        await connection.execute(
          `INSERT INTO recipe_components (combined_recipe_id, source_recipe_id, multiplier, user_id)
           VALUES (?, ?, ?, ?)`,
          [recipeId, s.source_recipe_id, s.multiplier ?? 1.0, cognito_id]
        );
      }
    }

    // For each ingredient, link (with quantity + unit)
    for (let i = 0; i < ingredients.length; i++) {
      const name = ingredients[i];
      const qty = quantities[i];
      const unit = units[i];
      console.log(`Processing ${name}: ${qty} ${unit}`);

      if (!name || !String(name).trim()) continue;

      // Find or create ingredient (user-scoped)
      const [ingRows] = await connection.execute(
        `SELECT id FROM ingredients WHERE ingredient_name = ? AND user_id = ?`,
        [String(name).trim(), cognito_id]
      );

      let ingredientId;
      if (ingRows.length) {
        ingredientId = ingRows[0].id;
      } else {
        const [ingRes] = await connection.execute(
          `INSERT INTO ingredients (ingredient_name, user_id) VALUES (?, ?)`,
          [String(name).trim(), cognito_id]
        );
        ingredientId = ingRes.insertId;
      }

      // Link in recipe_ingredients (with unit)
      await connection.execute(
        `INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, user_id)
         VALUES (?, ?, ?, ?, ?)`,
        [
          recipeId,
          ingredientId,
          qty === undefined || qty === null || qty === "" ? 0 : qty,
          unit ? String(unit) : "",
          cognito_id,
        ]
      );

      console.log(`Linked ingredient ${ingredientId} → recipe ${recipeId}`);
    }

    await connection.commit();
    console.log("Transaction committed");

    res.status(200).json({
      message: "Recipe added successfully!",
      recipe_id: recipeId,
      is_combined: isCombined,
    });
  } catch (err) {
    await connection.rollback();
    console.error("Error, rolled back:", err);
    res.status(500).json({ error: "Database transaction failed", details: err.message });
  } finally {
    connection.release();
    console.log("Connection released");
  }
});

// ==============================
// GET /api/recipes (UPDATED: include notes + is_combined)
// ==============================
app.get("/api/recipes", async (req, res) => {
  const { cognito_id } = req.query;

  if (!cognito_id) {
    console.error("Missing cognito_id in request query:", req.query);
    return res.status(400).json({ error: "cognito_id is required" });
  }

  try {
    const [results] = await db.promise().query(
      `
      SELECT
        r.id AS recipe_id,
        r.recipe_name AS recipe,
        r.units_per_batch,
        IFNULL(r.notes, '') AS notes,
        IFNULL(r.is_combined, 0) AS is_combined,
        i.ingredient_name AS ingredient,
        ri.quantity,
        IFNULL(ri.unit, '') AS unit
      FROM recipes r
      JOIN recipe_ingredients ri ON r.id = ri.recipe_id AND ri.user_id = r.user_id
      JOIN ingredients i ON ri.ingredient_id = i.id AND i.user_id = r.user_id
      WHERE r.user_id = ?
      ORDER BY r.id, ri.id
      `,
      [cognito_id]
    );

    res.json(results);
  } catch (err) {
    console.error("Failed to fetch recipes:", err);
    res.status(500).json({ error: "Failed to fetch recipes" });
  }
});

// ==============================
// POST /api/delete-recipe (UPDATED: also deletes recipe_components rows)
// ==============================
app.post("/api/delete-recipe", async (req, res) => {
  const { recipeName, cognito_id } = req.body;

  if (!recipeName || !cognito_id) {
    return res.status(400).json({ error: "recipeName and cognito_id are required" });
  }

  const connection = await db.promise().getConnection();
  try {
    await connection.beginTransaction();

    console.log("Received delete-recipe request:", { recipeName, cognito_id });

    const [recipeCheck] = await connection.execute(
      "SELECT id FROM recipes WHERE recipe_name = ? AND user_id = ? LIMIT 1",
      [recipeName, cognito_id]
    );

    if (recipeCheck.length === 0) {
      await connection.rollback();
      return res.status(404).json({ error: "Recipe not found or does not belong to this user" });
    }

    const recipeId = recipeCheck[0].id;

    // Remove recipe_components referencing this recipe (as combined OR source)
    await connection.execute(
      "DELETE FROM recipe_components WHERE user_id = ? AND (combined_recipe_id = ? OR source_recipe_id = ?)",
      [cognito_id, recipeId, recipeId]
    );

    // Delete associated recipe_ingredients
    await connection.execute(
      "DELETE FROM recipe_ingredients WHERE recipe_id = ? AND user_id = ?",
      [recipeId, cognito_id]
    );

    // Delete the recipe
    await connection.execute(
      "DELETE FROM recipes WHERE id = ? AND user_id = ?",
      [recipeId, cognito_id]
    );

    await connection.commit();
    res.status(200).json({ message: "Recipe deleted successfully" });
  } catch (err) {
    await connection.rollback();
    console.error("Error deleting recipe:", err);
    res.status(500).json({ error: "Error deleting recipe" });
  } finally {
    connection.release();
  }
});

// ==============================
// GET /dev/get-recipes (unchanged but fine)
// ==============================
app.get("/dev/get-recipes", (req, res) => {
  const { cognito_id } = req.query;

  if (!cognito_id) {
    return res.status(400).json({ message: "cognito_id is required" });
  }

  const query = `
    SELECT DISTINCT
      recipe_name,
      IFNULL(notes, '') AS notes
    FROM recipes
    WHERE user_id = ?
    ORDER BY recipe_name ASC;
  `;

  db.query(query, [cognito_id], (error, results) => {
    if (error) {
      return res.status(500).json({ message: "Error fetching recipes", error });
    }
    res.json(results);
  });
});

// ==============================
// PUT /api/recipes/:id (UPDATED: supports notes + combined recipe_components + is_combined)
// ==============================
app.put("/api/recipes/:id", async (req, res) => {
  const recipeId = req.params.id;

  const {
    recipe,
    upb,
    notes,
    ingredients,
    quantities,
    units,
    cognito_id,
    combined,
    recipe_meta,
    combined_meta,
  } = req.body;

  const combinedMeta = normalizeCombinedMeta({ combined, recipe_meta, combined_meta });

  res.setHeader("Access-Control-Allow-Origin", FRONTEND_ORIGIN);
  res.setHeader("Access-Control-Allow-Credentials", "true");

  if (!recipeId) return res.status(400).json({ error: "recipe id required in path" });
  if (!cognito_id) return res.status(400).json({ error: "cognito_id is required" });
  if (!recipe) return res.status(400).json({ error: "recipe name is required" });

  if (
    !Array.isArray(ingredients) ||
    !Array.isArray(quantities) ||
    !Array.isArray(units) ||
    ingredients.length !== quantities.length ||
    ingredients.length !== units.length
  ) {
    return res.status(400).json({
      error: "ingredients, quantities, units arrays must be same length",
    });
  }

  const conn = await db.promise().getConnection();
  try {
    console.info(`[PUT.recipes] Starting transaction for recipe=${recipeId} user=${cognito_id}`);
    await conn.beginTransaction();

    // Verify ownership
    const [found] = await conn.execute(
      `SELECT id, user_id FROM recipes WHERE id = ? LIMIT 1`,
      [recipeId]
    );

    if (!found || found.length === 0 || String(found[0].user_id) !== String(cognito_id)) {
      await conn.rollback();
      console.warn(`[PUT.recipes] recipe not found or not owned: recipe=${recipeId}, user=${cognito_id}`);
      return res.status(404).json({ error: "Recipe not found or not owned by user" });
    }

    const isCombined =
      combinedMeta && (combinedMeta.sources?.length || combinedMeta.extras?.length) ? 1 : 0;

    // Update recipes meta (includes notes + is_combined)
    await conn.execute(
      `UPDATE recipes
         SET recipe_name = ?, units_per_batch = ?, notes = ?, is_combined = ?
       WHERE id = ? AND user_id = ?`,
      [recipe, upb, normalizeNotes(notes), isCombined, recipeId, cognito_id]
    );

    // Update recipe_components for combined recipes
    // Strategy: delete & reinsert for this combined recipe
    await conn.execute(
      `DELETE FROM recipe_components WHERE combined_recipe_id = ? AND user_id = ?`,
      [recipeId, cognito_id]
    );

    if (isCombined) {
      const sources = combinedMeta?.sources || [];
      for (const s of sources) {
        const [check] = await conn.execute(
          `SELECT id FROM recipes WHERE id = ? AND user_id = ? LIMIT 1`,
          [s.source_recipe_id, cognito_id]
        );
        if (!check || check.length === 0) {
          console.warn(`[PUT.recipes] skipping source_recipe_id=${s.source_recipe_id} (not owned)`);
          continue;
        }
        await conn.execute(
          `INSERT INTO recipe_components (combined_recipe_id, source_recipe_id, multiplier, user_id)
           VALUES (?, ?, ?, ?)`,
          [recipeId, s.source_recipe_id, s.multiplier ?? 1.0, cognito_id]
        );
      }
    }

    // Delete existing recipe_ingredients for this recipe & user
    await conn.execute(
      `DELETE FROM recipe_ingredients WHERE recipe_id = ? AND user_id = ?`,
      [recipeId, cognito_id]
    );

    // Re-insert recipe_ingredients
    for (let i = 0; i < ingredients.length; i++) {
      const ingName = String(ingredients[i] ?? "").trim();
      const qty = quantities[i];
      const unitVal = units[i];

      if (!ingName) continue;

      const [ingRows] = await conn.execute(
        `SELECT id FROM ingredients WHERE ingredient_name = ? AND user_id = ? LIMIT 1`,
        [ingName, cognito_id]
      );

      let ingredientId;
      if (ingRows && ingRows.length) {
        ingredientId = ingRows[0].id;
      } else {
        const [ins] = await conn.execute(
          `INSERT INTO ingredients (ingredient_name, user_id) VALUES (?, ?)`,
          [ingName, cognito_id]
        );
        ingredientId = ins.insertId;
      }

      await conn.execute(
        `INSERT INTO recipe_ingredients (recipe_id, ingredient_id, quantity, unit, user_id)
         VALUES (?, ?, ?, ?, ?)`,
        [
          recipeId,
          ingredientId,
          qty === undefined || qty === null || qty === "" ? 0 : qty,
          unitVal ? String(unitVal) : "",
          cognito_id,
        ]
      );
    }

    await conn.commit();
    console.info(`[PUT.recipes] Commit successful recipe=${recipeId} user=${cognito_id}`);

    // Return updated recipe rows (same style as before)
    const [updatedRows] = await db.promise().execute(
      `SELECT
          r.id AS recipe_id,
          r.recipe_name,
          r.units_per_batch,
          IFNULL(r.notes,'') AS notes,
          IFNULL(r.is_combined,0) AS is_combined,
          i.ingredient_name,
          ri.quantity,
          IFNULL(ri.unit,'') AS unit
       FROM recipes r
       JOIN recipe_ingredients ri ON ri.recipe_id = r.id AND ri.user_id = r.user_id
       JOIN ingredients i ON i.id = ri.ingredient_id AND i.user_id = r.user_id
       WHERE r.id = ? AND r.user_id = ?
       ORDER BY ri.id ASC`,
      [recipeId, cognito_id]
    );

    return res.json({ success: true, updated: updatedRows });
  } catch (err) {
    await conn.rollback();
    console.error("[PUT.recipes] DB error, rollback:", err);
    return res.status(500).json({ error: "Database error", details: err.message });
  } finally {
    conn.release();
  }
});

// ==============================
// GET /api/recipes/:id (UPDATED: fixes recipe_components schema + returns combined meta for frontend)
// ==============================
app.get("/api/recipes/:id", async (req, res) => {
  const recipeId = req.params.id;
  const cognito_id = req.query.cognito_id;
  const start = Date.now();

  res.setHeader("Access-Control-Allow-Origin", FRONTEND_ORIGIN);
  res.setHeader("Access-Control-Allow-Credentials", "true");

  console.info(
    `[GET.recipes.id] incoming request recipeId=${recipeId} query=${JSON.stringify(req.query)}`
  );

  if (!recipeId) return res.status(400).json({ error: "recipe id required in path" });
  if (!cognito_id) return res.status(400).json({ error: "cognito_id is required" });

  const conn = await db.promise().getConnection();
  try {
    const sql = `
      SELECT 
        r.id as recipe_id,
        r.recipe_name,
        r.units_per_batch,
        IFNULL(r.notes,'') AS notes,
        IFNULL(r.is_combined,0) AS is_combined,

        ri.id as recipe_ingredient_id,
        ri.quantity,
        IFNULL(ri.unit,'') AS unit,

        i.id as ingredient_id,
        i.ingredient_name
      FROM recipes r
      LEFT JOIN recipe_ingredients ri 
        ON ri.recipe_id = r.id 
       AND ri.user_id = r.user_id
      LEFT JOIN ingredients i 
        ON i.id = ri.ingredient_id 
       AND i.user_id = r.user_id
      WHERE r.id = ? AND r.user_id = ?
      ORDER BY ri.id ASC
    `;

    const [rows] = await conn.execute(sql, [recipeId, cognito_id]);

    if (!rows || rows.length === 0) {
      return res.status(404).json({ error: "Recipe not found or not owned by user" });
    }

    const recipeMeta = rows[0];

    const ingredients = rows
      .filter((r) => r.ingredient_name !== null && r.ingredient_id !== null)
      .map((r) => ({
        recipe_ingredient_id: r.recipe_ingredient_id,
        ingredient_id: r.ingredient_id,
        ingredient_name: r.ingredient_name,
        quantity: r.quantity,
        unit: r.unit,
      }));

    // If combined: return components + combined meta (for drawer grouping)
    let components = [];
    let combined_meta = null;

    if (Number(recipeMeta.is_combined) === 1) {
      const [compRows] = await conn.execute(
        `
        SELECT combined_recipe_id, source_recipe_id, multiplier, created_at
        FROM recipe_components
        WHERE combined_recipe_id = ? AND user_id = ?
        ORDER BY created_at ASC, source_recipe_id ASC
        `,
        [recipeId, cognito_id]
      );

      components = (compRows || []).map((c) => ({
        combined_recipe_id: c.combined_recipe_id,
        source_recipe_id: c.source_recipe_id,
        multiplier: c.multiplier,
        created_at: c.created_at,
      }));

      // Build the exact shape your frontend Drawer normaliser can read
      combined_meta = await buildCombinedMetaFromDb(conn, Number(recipeId), cognito_id);
    }

    const payload = {
      recipe_id: recipeMeta.recipe_id,
      recipe_name: recipeMeta.recipe_name,
      units_per_batch: recipeMeta.units_per_batch,
      notes: recipeMeta.notes,
      is_combined: Number(recipeMeta.is_combined) === 1 ? 1 : 0,
      components,
      combined_meta, // ✅ Drawer can use this to group by source recipe
      ingredients,
    };

    console.info(
      `[GET.recipes.id] Responding (${Date.now() - start}ms) ingredients=${ingredients.length} is_combined=${payload.is_combined} components=${components.length}`
    );

    return res.json(payload);
  } catch (err) {
    console.error("[GET.recipes.id] DB error:", { message: err.message, stack: err.stack });
    return res.status(500).json({ error: "Database error", details: err.message });
  } finally {
    conn.release();
  }
});

app.post('/dev/api/add-user', async (req, res) => {
  try {
    const { cognito_id, email } = req.body;
    console.log("Received request at /api/add-user", req.body);

    if (!cognito_id || !email) {
      console.error("Missing fields:", { cognito_id, email });
      return res.status(400).json({ message: "Missing required fields" });
    }

    // Check if the email already exists in the database
    const [existingUser] = await db
      .promise()
      .query("SELECT * FROM users WHERE email = ?", [email]);

    if (existingUser.length > 0) {
      console.log("User already exists with email:", email);
      return res.status(200).json({ message: "User already exists!" });
    }

    // Insert new user if it doesn't already exist
    const [result] = await db
      .promise()
      .query("INSERT INTO users (cognito_id, email) VALUES (?, ?)", [
        cognito_id,
        email,
      ]);

    console.log("User inserted:", result);
    res.status(200).json({ message: "User added successfully!" });
  } catch (error) {
    console.error("Error while adding user:", error);
    res.status(500).json({ message: "Error registering user", error: error.message });
  }
});


app.post("/api/add-production-log", async (req, res) => {
  const {
    date,
    recipe,
    batchesProduced,
    batchCode,
    unitsOfWaste,
    cognito_id,

    // accept both camelCase and snake_case from the client
    producerName: producerNameFromBody,
    producer_name: producerNameSnake,

    // ✅ NEW: expiry date
    expiryDate,
    expiry_date,

    // ✅ checkbox flag (frontend)
    avoidExpiredGoods,
    avoid_expired_goods,
  } = req.body

  // prefer camelCase if provided, otherwise snake_case; fall back to null
  const producerName = producerNameFromBody ?? producerNameSnake ?? null

  // ✅ normalize expiry date
  const expiry = expiryDate ?? expiry_date ?? null

  // ✅ normalize checkbox flag
  const avoidExpired = Boolean(avoidExpiredGoods ?? avoid_expired_goods ?? false) === true

  console.log("📥 Received /add-production-log request:", {
    date,
    recipe,
    batchesProduced,
    batchCode,
    unitsOfWaste,
    cognito_id,
    producerName,
    expiry,
    avoidExpired,
  })

  if (
    date == null ||
    recipe == null ||
    batchesProduced == null ||
    batchCode == null ||
    unitsOfWaste == null ||
    cognito_id == null
  ) {
    console.error("❌ Missing fields in request:", req.body)
    return res.status(400).json({ error: "All fields are required, including cognito_id" })
  }

  const connection = await db.promise().getConnection()

  // --- helpers (server-side) ---
  const normalizeUnit = (u) => {
    const raw = (u || "").toString().trim().toLowerCase()
    if (!raw || raw === "n/a" || raw === "na" || raw === "none") return ""
    if (["g", "gram", "grams"].includes(raw)) return "g"
    if (["kg", "kilogram", "kilograms"].includes(raw)) return "kg"
    if (["ml", "millilitre", "milliliter", "milliliters", "millilitres"].includes(raw)) return "ml"
    if (["l", "liter", "litre", "liters", "litres"].includes(raw)) return "l"
    if (["unit", "units", "pcs", "pc", "piece", "pieces"].includes(raw)) return "unit"
    return raw
  }

  // factor to convert canonical unit -> base numeric unit
  const unitFactorToBase = (canonUnit) => {
    const u = (canonUnit || "").toString().toLowerCase()
    if (!u) return 1
    if (u === "kg") return 1000 // kg -> g
    if (u === "g") return 1
    if (u === "l") return 1000 // L -> ml
    if (u === "ml") return 1
    if (u === "unit") return 1
    return 1
  }

  // safe rounding when converting back to lot unit (limits floating point drift)
  const toFixedSafe = (num, decimals = 6) => {
    return Math.round(num * Math.pow(10, decimals)) / Math.pow(10, decimals)
  }

  const isYmd = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s)

  try {
    console.log("🔄 Starting database transaction...")
    await connection.beginTransaction()

    if (!isYmd(date)) {
      throw new Error(`Invalid production date format (expected YYYY-MM-DD): ${date}`)
    }
    if (expiry != null && expiry !== "" && !isYmd(expiry)) {
      throw new Error(`Invalid expiry date format (expected YYYY-MM-DD): ${expiry}`)
    }

    // fetch recipe + units_per_batch
    const [recipeRows] = await connection.execute(
      `SELECT id, units_per_batch
         FROM recipes
        WHERE recipe_name = ? AND user_id = ?`,
      [recipe, cognito_id],
    )

    if (recipeRows.length === 0) {
      console.error(`❌ Recipe not found for user: ${recipe} / ${cognito_id}`)
      await connection.rollback()
      return res.status(400).json({ error: "Recipe not found" })
    }

    const recipeId = recipeRows[0].id
    const unitsPerBatch = Number(recipeRows[0].units_per_batch) || 1
    const batchRemaining = Number(batchesProduced) * unitsPerBatch
    const finalUnitsOfWaste = Number(unitsOfWaste) || 0

    console.log("📤 Inserting production_log:", {
      date,
      recipe,
      batchesProduced,
      batchRemaining,
      batchCode,
      user_id: cognito_id,
      units_of_waste: finalUnitsOfWaste,
      producer_name: producerName,
      expiry_date: expiry,
      avoidExpired,
    })

    // ✅ Insert into production_log including producer_name + expiry_date (nullable)
    const [productionLogResult] = await connection.execute(
      `
      INSERT INTO production_log
        (date, recipe, batchesProduced, batchRemaining, batchCode, user_id, units_of_waste, producer_name, expiry_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        date,
        recipe,
        batchesProduced,
        batchRemaining,
        batchCode,
        cognito_id,
        finalUnitsOfWaste,
        producerName,
        expiry || null,
      ],
    )

    const productionLogId = productionLogResult.insertId
    console.log("✅ Inserted production_log ID:", productionLogId)

    // fetch recipe ingredients WITH UNIT and compute total needed (in recipe unit)
    const [ingredients] = await connection.execute(
      `
      SELECT
        i.id AS ingredient_id,
        i.ingredient_name,
        ri.unit AS unit,
        (ri.quantity * ?) AS total_needed
      FROM recipe_ingredients ri
      JOIN ingredients i ON ri.ingredient_id = i.id
      WHERE ri.recipe_id = ?
      `,
      [Number(batchesProduced), recipeId],
    )

    if (ingredients.length === 0) {
      console.error("❌ No ingredients found for recipe ID:", recipeId)
      throw new Error("No ingredients found for this recipe")
    }

    console.log("🔁 Deducting stock from goods_in (FIFO, active lots; unit-aware conversion)...")

    for (const ing of ingredients) {
      // amountNeeded is in the recipe unit (e.g., 10 if recipe says 10 g)
      let amountNeeded = Number(ing.total_needed) || 0
      const ingName = ing.ingredient_name
      const ingUnitRaw = ing.unit
      const ingUnitCanon = normalizeUnit(ingUnitRaw)
      const needBasePerUnit = unitFactorToBase(ingUnitCanon)
      // convert total need to base units (grams, ml, or units)
      let amountNeededBase = amountNeeded * needBasePerUnit

      console.log(`▶ ${ingName} (${ingUnitCanon || "no-unit"}): need ${amountNeeded} (${amountNeededBase} base)`)

      // loop until we've satisfied the need (in base units) or run out of lots
      while (amountNeededBase > 0) {
        // ✅ IMPORTANT FIX: compare expiryDate to PRODUCTION DATE, not CURDATE()
        const expiryClause = avoidExpired
          ? `AND (gi.expiryDate IS NULL OR DATE(gi.expiryDate) >= DATE(?))`
          : ``

        const sql = `
          SELECT gi.id, gi.stockRemaining, gi.barCode, gi.date, gi.unit, gi.expiryDate
            FROM goods_in gi
           WHERE gi.user_id = ?
             AND gi.ingredient = ?
             AND gi.deleted_at IS NULL
             AND gi.stockRemaining > 0
             ${expiryClause}
           ORDER BY gi.date ASC, gi.id ASC
           LIMIT 1
        `

        const params = avoidExpired ? [cognito_id, ingName, date] : [cognito_id, ingName]
        const [stockRows] = await connection.execute(sql, params)

        if (stockRows.length === 0) {
          const msg = `Insufficient ${avoidExpired ? "NON-EXPIRED " : ""}stock for ${ingName}. Remaining shortfall (base units): ${amountNeededBase}`
          console.warn(`⚠ ${msg}`)

          // ✅ hard block if checkbox ON
          if (avoidExpired) throw new Error(msg)

          break // old behavior if checkbox off
        }

        const { id: goodsInId, stockRemaining: lotStockRaw, unit: lotUnitRaw } = stockRows[0]

        const lotUnitCanon = normalizeUnit(lotUnitRaw)
        const lotFactor = unitFactorToBase(lotUnitCanon)
        const lotBase = (Number(lotStockRaw) || 0) * lotFactor

        // how much we'll take (in base units)
        const deductionBase = Math.min(amountNeededBase, lotBase)

        // compute new lot base and convert back to lot's stored unit
        const newLotBase = lotBase - deductionBase
        const newLotRemaining = toFixedSafe(newLotBase / (lotFactor || 1), 6)

        // Update the lot's stockRemaining in its original unit
        await connection.execute(`UPDATE goods_in SET stockRemaining = ? WHERE id = ?`, [newLotRemaining, goodsInId])

        // Record usage (existing schema)
        await connection.execute(
          `
          INSERT INTO stock_usage (production_log_id, goods_in_id, user_id)
          VALUES (?, ?, ?)
          `,
          [productionLogId, goodsInId, cognito_id],
        )

        amountNeededBase -= deductionBase
        console.log(
          `   • Used ${deductionBase} base units from goods_in.id=${goodsInId} (lot unit ${lotUnitCanon} => lotBase ${lotBase}). New lot remaining in lot unit: ${newLotRemaining}`,
        )
      } // end while per ingredient
    } // end for each ingredient

    await connection.commit()
    console.log("✅ Transaction committed.")
    res.status(200).json({
      message: "Production log saved successfully",
      id: productionLogId,
      producer_name: producerName,
      expiry_date: expiry || null,
      avoidExpiredGoods: avoidExpired,
    })
  } catch (err) {
    await connection.rollback()
    console.error("❌ Error in transaction:", err)
    res.status(500).json({ error: err.message })
  } finally {
    connection.release()
  }
})

app.post("/api/add-production-log/batch", async (req, res) => {
  const {
    entries,
    cognito_id,

    // ✅ top-level checkbox flag
    avoidExpiredGoods,
    avoid_expired_goods,
  } = req.body

  res.setHeader("Access-Control-Allow-Origin", "https://master.d2fdrxobxyr2je.amplifyapp.com")
  res.setHeader("Access-Control-Allow-Credentials", "true")

  if (!Array.isArray(entries) || entries.length === 0) {
    return res.status(400).json({ success: false, error: "entries must be a non-empty array" })
  }
  if (!cognito_id) {
    return res.status(400).json({ success: false, error: "cognito_id is required" })
  }

  const avoidExpiredBatch = Boolean(avoidExpiredGoods ?? avoid_expired_goods ?? false) === true

  // quick validation of each entry
  const invalid = entries
    .map((e, i) => {
      const missing = []
      if (e.date == null) missing.push("date")
      if (e.recipe == null) missing.push("recipe")
      if (e.batchesProduced == null) missing.push("batchesProduced")
      if (e.batchCode == null) missing.push("batchCode")
      if (e.unitsOfWaste == null) missing.push("unitsOfWaste")
      return missing.length ? { index: i, missing } : null
    })
    .filter(Boolean)

  if (invalid.length) {
    return res.status(400).json({ success: false, error: "Validation failed for some entries", details: invalid })
  }

  const connection = await db.promise().getConnection()

  // ---- helpers (mirror single route)
  const normalizeUnit = (u) => {
    const raw = (u || "").toString().trim().toLowerCase()
    if (!raw || raw === "n/a" || raw === "na" || raw === "none") return ""
    if (["g", "gram", "grams"].includes(raw)) return "g"
    if (["kg", "kilogram", "kilograms"].includes(raw)) return "kg"
    if (["ml", "millilitre", "milliliter", "milliliters", "millilitres"].includes(raw)) return "ml"
    if (["l", "liter", "litre", "liters", "litres"].includes(raw)) return "l"
    if (["unit", "units", "pcs", "pc", "piece", "pieces"].includes(raw)) return "unit"
    return raw
  }

  const unitFactorToBase = (canonUnit) => {
    const u = (canonUnit || "").toString().toLowerCase()
    if (!u) return 1
    if (u === "kg") return 1000 // kg -> g
    if (u === "g") return 1
    if (u === "l") return 1000 // L -> ml
    if (u === "ml") return 1
    if (u === "unit") return 1
    return 1
  }

  const toFixedSafe = (num, decimals = 6) => Math.round(num * Math.pow(10, decimals)) / Math.pow(10, decimals)

  const isYmd = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s)

  try {
    await connection.beginTransaction()

    const insertedIds = []

    // Process each entry in order (FIFO deductions are per-item)
    for (const entry of entries) {
      const {
        date,
        recipe,
        batchesProduced,
        batchCode,
        unitsOfWaste,
        producerName: producerNameFromBody,
        producer_name: producerNameSnake,

        // ✅ NEW: expiry date per-entry
        expiryDate,
        expiry_date,

        // ✅ optional per-entry override
        avoidExpiredGoods: entryAvoidExpiredGoods,
        avoid_expired_goods: entryAvoidExpiredGoodsSnake,
      } = entry

      if (!isYmd(date)) {
        throw new Error(`Invalid production date format (expected YYYY-MM-DD): ${date}`)
      }

      const expiry = expiryDate ?? expiry_date ?? null
      if (expiry != null && expiry !== "" && !isYmd(expiry)) {
        throw new Error(`Invalid expiry date format (expected YYYY-MM-DD): ${expiry}`)
      }

      const producerName = producerNameFromBody ?? producerNameSnake ?? null

      // entry override > batch flag
      const avoidExpiredEntry =
        Boolean(entryAvoidExpiredGoods ?? entryAvoidExpiredGoodsSnake ?? avoidExpiredBatch ?? false) === true

      // fetch recipe + units_per_batch
      const [recipeRows] = await connection.execute(
        `SELECT id, units_per_batch FROM recipes WHERE recipe_name = ? AND user_id = ?`,
        [recipe, cognito_id],
      )
      if (recipeRows.length === 0) {
        throw new Error(`Recipe not found: ${recipe}`)
      }

      const recipeId = recipeRows[0].id
      const unitsPerBatch = Number(recipeRows[0].units_per_batch) || 1
      const batchRemaining = Number(batchesProduced) * unitsPerBatch
      const finalUnitsOfWaste = Number(unitsOfWaste) || 0

      // ✅ insert production_log (returns id) INCLUDING expiry_date
      const [productionLogResult] = await connection.execute(
        `
          INSERT INTO production_log
            (date, recipe, batchesProduced, batchRemaining, batchCode, user_id, units_of_waste, producer_name, expiry_date)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [date, recipe, batchesProduced, batchRemaining, batchCode, cognito_id, finalUnitsOfWaste, producerName, expiry || null],
      )

      const productionLogId = productionLogResult.insertId
      insertedIds.push(productionLogId)

      // fetch recipe ingredients for this recipe
      const [ingredients] = await connection.execute(
        `
          SELECT
            i.id AS ingredient_id,
            i.ingredient_name,
            ri.unit AS unit,
            (ri.quantity * ?) AS total_needed
          FROM recipe_ingredients ri
          JOIN ingredients i ON ri.ingredient_id = i.id
          WHERE ri.recipe_id = ?
        `,
        [Number(batchesProduced), recipeId],
      )

      // Deduct from goods_in FIFO (active, any unit; convert to base)
      for (const ing of ingredients) {
        let amountNeeded = Number(ing.total_needed) || 0
        const ingName = ing.ingredient_name
        const ingUnitCanon = normalizeUnit(ing.unit)
        const needBasePerUnit = unitFactorToBase(ingUnitCanon)
        let amountNeededBase = amountNeeded * needBasePerUnit

        while (amountNeededBase > 0) {
          // ✅ IMPORTANT FIX: compare expiryDate to ENTRY DATE, not CURDATE()
          const expiryClause = avoidExpiredEntry
            ? `AND (gi.expiryDate IS NULL OR DATE(gi.expiryDate) >= DATE(?))`
            : ``

          const sql = `
            SELECT gi.id, gi.stockRemaining, gi.barCode, gi.date, gi.unit, gi.expiryDate
            FROM goods_in gi
            WHERE gi.user_id = ?
              AND gi.ingredient = ?
              AND gi.deleted_at IS NULL
              AND gi.stockRemaining > 0
              ${expiryClause}
            ORDER BY gi.date ASC, gi.id ASC
            LIMIT 1
          `

          const params = avoidExpiredEntry ? [cognito_id, ingName, date] : [cognito_id, ingName]
          const [stockRows] = await connection.execute(sql, params)

          if (stockRows.length === 0) {
            const msg = `Insufficient ${avoidExpiredEntry ? "NON-EXPIRED " : ""}stock for ${ingName} (batchCode=${batchCode}, date=${date}). Remaining shortfall (base units): ${amountNeededBase}`
            console.warn(`⚠ ${msg}`)

            // ✅ hard block if checkbox ON
            if (avoidExpiredEntry) throw new Error(msg)

            break // old behavior if checkbox off
          }

          const { id: goodsInId, stockRemaining: lotStockRaw, unit: lotUnitRaw } = stockRows[0]
          const lotUnitCanon = normalizeUnit(lotUnitRaw)
          const lotFactor = unitFactorToBase(lotUnitCanon)
          const lotBase = (Number(lotStockRaw) || 0) * lotFactor

          const deductionBase = Math.min(amountNeededBase, lotBase)
          const newLotBase = lotBase - deductionBase
          const newLotRemaining = toFixedSafe(newLotBase / (lotFactor || 1), 6)

          await connection.execute(`UPDATE goods_in SET stockRemaining = ? WHERE id = ?`, [newLotRemaining, goodsInId])

          await connection.execute(
            `INSERT INTO stock_usage (production_log_id, goods_in_id, user_id) VALUES (?, ?, ?)`,
            [productionLogId, goodsInId, cognito_id],
          )

          amountNeededBase -= deductionBase
        }
      }
    }

    await connection.commit()
    return res.status(200).json({
      success: true,
      message: `Inserted ${insertedIds.length} production log entries`,
      insertedIds,
      avoidExpiredGoods: avoidExpiredBatch,
    })
  } catch (err) {
    await connection.rollback()
    console.error("Batch production DB error:", { message: err.message, stack: err.stack })
    return res.status(500).json({ success: false, error: err.message })
  } finally {
    connection.release()
  }
})

// GET /api/ingredient-inventory/active?cognito_id=...
app.get("/api/ingredient-inventory/active", async (req, res) => {
  const { cognito_id } = req.query;
  if (!cognito_id) return res.status(400).json({ error: "cognito_id is required" });

  try {
    const [rows] = await db.promise().query(
      `
      SELECT
        gi.ingredient,
        gi.unit,
        SUM(gi.stockRemaining) AS totalRemaining,
        (
          SELECT gi2.barCode
          FROM goods_in gi2
          WHERE gi2.ingredient = gi.ingredient
            AND gi2.unit = gi.unit
            AND gi2.user_id = gi.user_id
            AND gi2.deleted_at IS NULL
            AND gi2.stockRemaining > 0
          ORDER BY gi2.date ASC, gi2.id ASC
          LIMIT 1
        ) AS activeBarcode,
        (
          SELECT gi2.expiryDate
          FROM goods_in gi2
          WHERE gi2.ingredient = gi.ingredient
            AND gi2.unit = gi.unit
            AND gi2.user_id = gi.user_id
            AND gi2.deleted_at IS NULL
            AND gi2.stockRemaining > 0
          ORDER BY gi2.date ASC, gi2.id ASC
          LIMIT 1
        ) AS activeExpiry
      FROM goods_in gi
      WHERE gi.user_id = ?
        AND gi.deleted_at IS NULL
        AND gi.stockRemaining > 0
      GROUP BY gi.ingredient, gi.unit
      ORDER BY gi.ingredient
      `,
      [cognito_id]
    );

    res.json(rows);
  } catch (err) {
    console.error("Error building ingredient inventory:", err);
    res.status(500).json({ error: "Database error" });
  }
});

app.get("/api/production-log/active", async (req, res) => {
  const { cognito_id } = req.query;
  if (!cognito_id) {
    console.error("Missing cognito_id in request:", req.query);
    return res.status(400).json({ error: "cognito_id is required" });
  }

  try {
    // compute derived fields server-side so clients see canonical values
    // include producer_name explicitly (and a camelCase alias producerName for client convenience)
    // ✅ NEW: include expiry_date (and camelCase alias expiryDate)
    const query = `
      SELECT
        pl.id,
        pl.date,
        pl.recipe,
        pl.batchesProduced,
        pl.batchRemaining,
        pl.batchCode,
        pl.user_id,
        pl.units_of_waste,

        -- ✅ NEW
        pl.expiry_date,
        pl.expiry_date AS expiryDate,

        pl.deleted_at,
        pl.deleted_by,
        pl.producer_name,
        COALESCE(pl.producer_name, '') AS producerName,
        COALESCE(r.units_per_batch, 0) AS units_per_batch,
        (pl.batchRemaining - COALESCE(pl.units_of_waste, 0)) AS unitsRemaining,
        CASE
          WHEN COALESCE(r.units_per_batch, 0) > 0
          THEN (pl.batchRemaining - COALESCE(pl.units_of_waste, 0)) / r.units_per_batch
          ELSE NULL
        END AS batchesRemaining
      FROM production_log pl
      LEFT JOIN recipes r ON r.recipe_name = pl.recipe AND r.user_id = pl.user_id
      WHERE pl.user_id = ? AND pl.deleted_at IS NULL
      ORDER BY pl.date DESC, pl.id DESC
    `;
    const [rows] = await db.promise().query(query, [cognito_id]);
    return res.json(rows);
  } catch (err) {
    console.error("Database error fetching production_log active:", err);
    return res.status(500).json({ error: "Database error", details: err.message });
  }
});

app.post("/api/delete-production-log", async (req, res) => {
  console.log("[/api/delete-production-log] Received:", req.body);
  const { batchCode, cognito_id } = req.body;

  if (!batchCode || !cognito_id) {
    console.error("[/api/delete-production-log] Missing batchCode or cognito_id");
    return res.status(400).json({ error: "batchCode and cognito_id are required" });
  }

  try {
    // 1) Ensure the row exists and isn't already soft-deleted
    const [existingRows] = await db
      .promise()
      .query(
        `SELECT id, batchCode, deleted_at
           FROM production_log
          WHERE LOWER(batchCode) = LOWER(?)
            AND user_id = ?
            AND deleted_at IS NULL`,
        [batchCode, cognito_id]
      );

    if (existingRows.length === 0) {
      console.warn("[/api/delete-production-log] Not found or already deleted:", { batchCode, cognito_id });
      return res.status(404).json({ error: "Row not found, already deleted, or not owned by this user" });
    }

    // 2) Soft delete (requires columns: deleted_at DATETIME NULL, deleted_by VARCHAR(64) NULL)
    const [result] = await db
      .promise()
      .query(
        `UPDATE production_log
            SET deleted_at = NOW(),
                deleted_by = ?
          WHERE LOWER(batchCode) = LOWER(?)
            AND user_id = ?
            AND deleted_at IS NULL`,
        [cognito_id, batchCode, cognito_id]
      );

    console.log("[/api/delete-production-log] Soft delete result:", result);

    if (result.affectedRows === 0) {
      // Race condition safety: someone may have deleted it between SELECT and UPDATE
      return res.status(409).json({ error: "Row was modified concurrently; please refresh" });
    }

    return res.json({ message: "Row soft-deleted" });
  } catch (err) {
    console.error("[/api/delete-production-log] Failed:", err);
    return res.status(500).json({ error: "Failed to soft-delete row" });
  }
});

app.put("/api/production-log/:batchCode", async (req, res) => {
  const { batchCode } = req.params;
  const body = req.body || {};
  const {
    date,
    recipe,
    batchesProduced,
    units_of_waste,
    unitsOfWaste,
    // client-editable value (NOT a DB column): when present, this drives batchRemaining
    unitsRemaining,
    producer_name,    // snake_case (preferred)
    producerName,     // camelCase (clients might send this)

    // ✅ NEW: expiry date (DB column)
    expiry_date,      // snake_case (preferred)
    expiryDate,       // camelCase (clients might send this)

    cognito_id,
  } = body;

  console.info("[PUT.production-log] called", { batchCode, body });

  if (!batchCode) return res.status(400).json({ error: "batchCode is required in path" });
  if (!cognito_id) return res.status(400).json({ error: "cognito_id is required" });

  const conn = await db.promise().getConnection();

  // ✅ helper: validate YYYY-MM-DD if provided
  const isYmd = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);

  try {
    await conn.beginTransaction();
    console.info("[PUT.production-log] transaction started for user:", cognito_id);

    // fetch existing row
    const [existingRows] = await conn.execute(
      `SELECT * FROM production_log WHERE batchCode = ? AND user_id = ? AND deleted_at IS NULL LIMIT 1`,
      [batchCode, cognito_id]
    );

    if (!existingRows || !existingRows.length) {
      await conn.rollback();
      console.warn("[PUT.production-log] no matching row found for", { batchCode, cognito_id });
      return res.status(404).json({ error: "No matching production_log row found for that batchCode/user" });
    }
    const existing = existingRows[0];

    // resolve units_of_waste value (prefer explicit in body; otherwise keep existing)
    const newUnitsOfWaste =
      units_of_waste !== undefined ? Number(units_of_waste)
      : unitsOfWaste !== undefined ? Number(unitsOfWaste)
      : Number(existing.units_of_waste || 0);

    // resolve producer name preference (do not force update unless provided)
    const producerProvided = producer_name !== undefined || producerName !== undefined;
    const newProducerName = producer_name !== undefined
      ? producer_name
      : (producerName !== undefined ? producerName : existing.producer_name ?? existing.producerName ?? null);

    // ✅ resolve expiry date (do not force update unless provided)
    const expiryProvided = expiry_date !== undefined || expiryDate !== undefined;
    const newExpiryDate = expiry_date !== undefined
      ? expiry_date
      : (expiryDate !== undefined ? expiryDate : existing.expiry_date ?? existing.expiryDate ?? null);

    // validate dates if provided
    if (date !== undefined && date !== null && date !== "" && !isYmd(date)) {
      await conn.rollback();
      return res.status(400).json({ error: `Invalid date format (expected YYYY-MM-DD): ${date}` });
    }
    if (expiryProvided) {
      // allow null/empty to clear the expiry_date
      if (newExpiryDate !== null && newExpiryDate !== "" && !isYmd(newExpiryDate)) {
        await conn.rollback();
        return res.status(400).json({ error: `Invalid expiry date format (expected YYYY-MM-DD): ${newExpiryDate}` });
      }
    }

    // Determine recipe to use for the lookup (body.recipe overrides existing.recipe)
    const recipeToUse = (recipe !== undefined && recipe !== null && String(recipe).trim() !== "")
      ? recipe
      : existing.recipe;

    // Fetch units_per_batch (UPB) for recipe (scoped to user) — used to return batchesRemaining in response
    let upb = 0;
    try {
      const [recipeRows] = await conn.execute(
        `SELECT id, units_per_batch FROM recipes WHERE recipe_name = ? AND user_id = ? LIMIT 1`,
        [recipeToUse, cognito_id]
      );
      if (Array.isArray(recipeRows) && recipeRows.length) {
        upb = Number(recipeRows[0].units_per_batch || 0) || 0;
      } else {
        upb = 0;
      }
    } catch (err) {
      console.warn("[PUT.production-log] warning: failed to lookup recipe UPB:", err && err.message ? err.message : err);
      upb = 0;
    }

    // Only update batchRemaining when client supplies unitsRemaining explicitly.
    // If unitsRemaining provided => compute batchRemaining_units = unitsRemaining + units_of_waste
    // If not provided => DO NOT touch batchRemaining (leave DB value unchanged).
    let computedBatchRemainingUnits = null; // null => do not update DB batchRemaining

    if (unitsRemaining !== undefined && unitsRemaining !== null && unitsRemaining !== "") {
      const uRem = Number(unitsRemaining || 0);
      computedBatchRemainingUnits = uRem + (Number(newUnitsOfWaste) || 0);
      console.info("[PUT.production-log] will update batchRemaining (units) from unitsRemaining:", {
        unitsRemaining: uRem,
        units_of_waste: newUnitsOfWaste,
        batchRemaining_units: computedBatchRemainingUnits
      });
    } else {
      console.info("[PUT.production-log] unitsRemaining not supplied by client — will NOT modify batchRemaining");
    }

    // Build update columns for DB (only real DB columns)
    const updateCols = [];
    const params = [];

    if (date !== undefined) { updateCols.push("date = ?"); params.push(date); }
    if (recipe !== undefined) { updateCols.push("recipe = ?"); params.push(recipe); }
    if (batchesProduced !== undefined) { updateCols.push("batchesProduced = ?"); params.push(Number(batchesProduced)); }

    // ✅ Update expiry_date only if explicitly provided
    if (expiryProvided) {
      updateCols.push("expiry_date = ?");
      params.push(newExpiryDate === "" ? null : newExpiryDate);
    }

    // Only include batchRemaining if we computed it from unitsRemaining above
    if (computedBatchRemainingUnits !== null) {
      updateCols.push("batchRemaining = ?");
      params.push(Number(computedBatchRemainingUnits));
    }

    // Update units_of_waste only if explicitly provided
    if (units_of_waste !== undefined || unitsOfWaste !== undefined) {
      updateCols.push("units_of_waste = ?");
      params.push(Number(newUnitsOfWaste));
    }

    // Update producer_name only if provided by client
    if (producerProvided) {
      updateCols.push("producer_name = ?");
      params.push(newProducerName);
    }

    if (updateCols.length === 0) {
      await conn.rollback();
      console.warn("[PUT.production-log] nothing to update");
      return res.status(400).json({ error: "No updatable fields supplied" });
    }

    // add WHERE params
    params.push(batchCode, cognito_id);

    const updateSql = `UPDATE production_log SET ${updateCols.join(", ")} WHERE batchCode = ? AND user_id = ? AND deleted_at IS NULL`;
    console.info("[PUT.production-log] Executing update:", updateSql, "params:", params);
    await conn.execute(updateSql, params);

    // Re-select the updated row and join recipe UPB for the response, compute derived fields server-side
    const [updatedRows] = await conn.execute(
      `SELECT pl.*, COALESCE(r.units_per_batch,0) AS units_per_batch
       FROM production_log pl
       LEFT JOIN recipes r ON r.recipe_name = pl.recipe AND r.user_id = pl.user_id
       WHERE pl.batchCode = ? AND pl.user_id = ? LIMIT 1`,
      [batchCode, cognito_id]
    );

    if (!updatedRows || !updatedRows.length) {
      await conn.rollback();
      console.error("[PUT.production-log] failed to fetch updated row after update");
      return res.status(500).json({ error: "Failed to fetch updated row" });
    }

    const updated = updatedRows[0];
    // compute returned derived values (server truth)
    const returnedBatchRemainingUnits = Number(updated.batchRemaining || 0);
    const returnedUnitsOfWaste = Number(updated.units_of_waste || 0);
    const returnedUnitsRemaining = returnedBatchRemainingUnits - returnedUnitsOfWaste;
    const returnedUPB = Number(updated.units_per_batch || 0);
    const returnedBatchesRemaining = returnedUPB > 0 ? Number(returnedUnitsRemaining) / returnedUPB : null;

    await conn.commit();
    console.info("[PUT.production-log] commit successful, returning updated row with derived fields");

    return res.json({
      success: true,
      updated: {
        ...updated,
        // make sure producer_name is included in the returned object (it comes from DB if present)
        producer_name: updated.producer_name ?? updated.producerName ?? null,

        // ✅ include expiry_date + camelCase alias
        expiry_date: updated.expiry_date ?? updated.expiryDate ?? null,
        expiryDate: updated.expiry_date ?? updated.expiryDate ?? null,

        unitsRemaining: returnedUnitsRemaining,
        batchesRemaining: returnedBatchesRemaining,
      },
    });
  } catch (err) {
    await conn.rollback().catch(() => {});
    console.error("[PUT.production-log] DB error:", err && err.message ? err.message : err);
    return res.status(500).json({ error: "Database error", details: err && err.message ? err.message : String(err) });
  } finally {
    conn.release();
  }
});

/* Helper: syncProductionInventoryForUser (simple template) */
async function syncProductionInventoryForUser(cognito_id, connArg = null) {
  const conn = connArg || (await db.promise().getConnection());
  let mustRelease = !connArg;
  try {
    console.info("[syncProductionInventoryForUser] computing totals for user:", cognito_id);
    const sql = `
      SELECT recipe, SUM(COALESCE(unitsRemaining, 0)) AS totalUnitsRemaining
      FROM production_log
      WHERE user_id = ? AND deleted_at IS NULL
      GROUP BY recipe
    `;
    const [rows] = await conn.execute(sql, [cognito_id]);
    console.info("[syncProductionInventoryForUser] rows:", rows.length);

    for (const r of rows) {
      // Upsert into production_inventory (example table)
      await conn.execute(
        `INSERT INTO production_inventory (recipe, amount, user_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE amount = VALUES(amount)`,
        [r.recipe, Number(r.totalUnitsRemaining || 0), cognito_id]
      );
    }
    console.info("[syncProductionInventoryForUser] done");
  } catch (err) {
    console.error("[syncProductionInventoryForUser] error:", err);
    throw err;
  } finally {
    if (mustRelease) conn.release();
  }
}

// GET /api/stock-usage/:cognitoId
app.get('/api/stock-usage/:cognitoId', (req, res) => {
  const cognitoId = req.params.cognitoId;
  console.log(`[GET] /api/stock-usage/${cognitoId}`);

  const sqlQuery = `
    SELECT 
      su.production_log_id,
      GROUP_CONCAT(DISTINCT su.id ORDER BY su.id) AS stock_usage_ids,   -- IDs for deletion
      pl.date AS production_log_date,
      r.recipe_name,
      pl.batchCode,
      pl.batchRemaining,
      pl.user_id AS production_log_user_id,
      r.id AS recipe_id,
      i.id AS ingredient_id,
      i.ingredient_name,
      ri.quantity,
      ri.unit,                                           -- <-- include unit
      pl.batchesProduced,
      GROUP_CONCAT(DISTINCT gi.barCode ORDER BY gi.id SEPARATOR ', ') AS ingredient_barcodes
    FROM stock_usage su
    JOIN production_log pl ON su.production_log_id = pl.id
    JOIN recipes r ON pl.recipe = r.recipe_name
    JOIN recipe_ingredients ri ON r.id = ri.recipe_id
    JOIN ingredients i ON ri.ingredient_id = i.id
    JOIN goods_in gi ON gi.id = su.goods_in_id AND gi.ingredient = i.ingredient_name
    WHERE su.user_id = ?
    GROUP BY
      su.production_log_id, pl.date, pl.batchCode, pl.batchRemaining,
      pl.user_id, r.id, i.id, i.ingredient_name, ri.quantity, ri.unit, pl.batchesProduced
  `;

  console.log('[GET /api/stock-usage] Executing SQL:\n', sqlQuery);

  db.query(sqlQuery, [cognitoId], (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      return res.status(500).json({ error: 'Database query failed' });
    }

    // Each row = one ingredient line for a production_log
    const formatted = (results || []).map((row) => {
      // Parse "1,2,3" -> [1,2,3]
      const ids =
        String(row.stock_usage_ids || '')
          .split(',')
          .map((s) => Number(s.trim()))
          .filter((n) => Number.isFinite(n));

      const qtyNum = Number(row.quantity) || 0;
      const batches = Number(row.batchesProduced) || 0;
      const unit = row.unit ?? ""; // unit from recipe_ingredients
      const totalQuantity = qtyNum * batches;

      return {
        production_log_id: row.production_log_id,
        production_log_date: row.production_log_date,
        recipe_name: row.recipe_name,
        batchCode: row.batchCode,
        batchRemaining: row.batchRemaining,
        production_log_user_id: row.production_log_user_id,
        recipe_id: row.recipe_id,
        batchesProduced: row.batchesProduced,
        ids, // carry array of stock_usage ids
        ingredients: [
          {
            ingredient_id: row.ingredient_id,
            ingredient_name: row.ingredient_name,
            ingredient_barcodes: row.ingredient_barcodes,
            quantity: qtyNum,
            unit: unit,
            total_quantity: totalQuantity,
          },
        ],
      };
    });

    // Group by production_log (collapsing ingredients & merging id arrays)
    const grouped = formatted.reduce((acc, row) => {
      const key = row.production_log_id;
      let group = acc.find((g) => g.production_log_id === key);

      if (!group) {
        group = {
          production_log_id: row.production_log_id,
          production_log_date: row.production_log_date,
          recipe_name: row.recipe_name,
          batchCode: row.batchCode,
          batchRemaining: row.batchRemaining,
          production_log_user_id: row.production_log_user_id,
          recipe_id: row.recipe_id,
          batchesProduced: row.batchesProduced,
          ids: [...row.ids],
          ingredients: [...row.ingredients], // first ingredient
        };
        acc.push(group);
      } else {
        // merge unique IDs
        const merged = new Set([...(group.ids || []), ...row.ids]);
        group.ids = Array.from(merged);

        // add ingredient if new (check by ingredient_id)
        const incoming = row.ingredients[0];
        if (!group.ingredients.some((ing) => ing.ingredient_id === incoming.ingredient_id)) {
          group.ingredients.push(incoming);
        }
      }
      return acc;
    }, []);

    console.log('[GET /api/stock-usage] Response groups:', grouped.length);
    res.json(grouped);
  });
});

// Hard-delete stock_usage rows by ids, owned by the given user
app.post("/api/stock-usage/delete", async (req, res) => {
  let { ids, id, cognito_id } = req.body;

  console.log("[/api/stock-usage/delete] body:", req.body);

  // Normalize to an array
  if (!Array.isArray(ids)) ids = typeof id !== "undefined" ? [id] : [];
  // Coerce to numbers (if your stock_usage.id is numeric)
  ids = ids.map((x) => Number(x)).filter((x) => Number.isFinite(x));

  // Basic validation
  if (!cognito_id || ids.length === 0) {
    return res.status(400).json({ error: "cognito_id and at least one id are required" });
  }

  // If stock_usage.user_id stores an *internal numeric* user id instead of the Cognito sub,
  // UNCOMMENT this lookup and use `internalUserId` in the queries below:
  //
  // const [[userRow]] = await db
  //   .promise()
  //   .query("SELECT id FROM users WHERE cognito_id = ? LIMIT 1", [cognito_id]);
  // if (!userRow) return res.status(404).json({ error: "Unknown user" });
  // const userKey = userRow.id; // internal numeric
  //
  // Otherwise, if stock_usage.user_id stores the Cognito sub directly, use:
  const userKey = cognito_id;

  // Build placeholders (?, ?, ...) for the IN() clause
  const inPlaceholders = ids.map(() => "?").join(", ");

  try {
    // 1) Which rows exist for those ids?
    const [rowsAnyUser] = await db
      .promise()
      .query(`SELECT id, user_id FROM stock_usage WHERE id IN (${inPlaceholders})`, ids);

    if (rowsAnyUser.length === 0) {
      return res.status(404).json({ error: "No matching rows for provided ids", ids });
    }

    // 2) Which rows belong to this user?
    const [rowsThisUser] = await db
      .promise()
      .query(
        `SELECT id FROM stock_usage WHERE id IN (${inPlaceholders}) AND user_id = ?`,
        [...ids, userKey]
      );

    if (rowsThisUser.length === 0) {
      // Helpful diagnostics when user_id mismatches (e.g., internal numeric vs cognito sub)
      return res.status(403).json({
        error: "Rows do not belong to this user_id. Check user_id type/mapping.",
        sampleRowUserIds: rowsAnyUser.slice(0, 5).map((r) => r.user_id),
        cognito_id_received: cognito_id,
      });
    }

    // 3) Delete
    const [result] = await db
      .promise()
      .query(
        `DELETE FROM stock_usage
         WHERE id IN (${inPlaceholders})
           AND user_id = ?`,
        [...ids, userKey]
      );

    return res.json({
      message: "Stock usage rows hard-deleted",
      requested: ids.length,
      matchedForUser: rowsThisUser.length,
      deleted: result.affectedRows,
    });
  } catch (err) {
    console.error("[/api/stock-usage/delete] Failed:", err);
    return res.status(500).json({ error: "Failed to hard-delete stock usage rows" });
  }
});

// =========================
// GOODS OUT — SINGLE
// ✅ Reads avoidExpiredGoods (camel + snake) from request
// ✅ When avoidExpiredGoods=true:
//    - Only deduct from production_log rows where expiryDate IS NULL OR expiryDate >= goods-out date
//    - If not enough stock, THROW + ROLLBACK (hard block)
// ✅ Does NOT store flag in DB
// =========================
app.post("/api/add-goods-out", async (req, res) => {
  const {
    date,
    recipe,
    stockAmount,
    recipients,
    cognito_id,
    avoidExpiredGoods, // read-only, not stored
  } = req.body;

  // Optional: keep CORS consistent with your batch endpoint
  res.setHeader("Access-Control-Allow-Origin", "https://master.d2fdrxobxyr2je.amplifyapp.com");
  res.setHeader("Access-Control-Allow-Credentials", "true");

  const missing = [];
  if (!date) missing.push("date");
  if (!recipe) missing.push("recipe");
  if (stockAmount === undefined || stockAmount === null || stockAmount === "") missing.push("stockAmount");
  if (!recipients) missing.push("recipients");
  if (!cognito_id) missing.push("cognito_id");

  if (missing.length) {
    return res.status(400).json({
      error: "All fields are required",
      code: "VALIDATION_ERROR",
      missing,
    });
  }

  const goodsOutDate = String(date).slice(0, 10);
  const useNonExpiredOnly = !!avoidExpiredGoods;

  const connection = await db.promise().getConnection();
  try {
    await connection.beginTransaction();

    // 0) Ensure recipe exists for this user
    const [recipeRows] = await connection.execute(
      `SELECT units_per_batch
         FROM recipes
        WHERE recipe_name = ?
          AND user_id = ?
        LIMIT 1`,
      [recipe, cognito_id]
    );

    if (!Array.isArray(recipeRows) || recipeRows.length === 0) {
      await connection.rollback();
      return res.status(400).json({
        error: `Recipe '${recipe}' not found for this user`,
        code: "RECIPE_NOT_FOUND",
        recipe,
      });
    }

    // NOTE: you currently treat stockAmount as "batches"
    const batchesToDeduct = Math.ceil(Number(stockAmount));
    if (!Number.isFinite(batchesToDeduct) || batchesToDeduct <= 0) {
      await connection.rollback();
      return res.status(400).json({
        error: "stockAmount must be a positive number",
        code: "VALIDATION_ERROR",
        field: "stockAmount",
      });
    }

    let remainingToDeduct = batchesToDeduct;

    // 1) Insert goods_out record
    const [goodsOutResult] = await connection.execute(
      `INSERT INTO goods_out (date, recipe, stockAmount, recipients, user_id)
       VALUES (?, ?, ?, ?, ?)`,
      [goodsOutDate, recipe, stockAmount, recipients, cognito_id]
    );
    const goodsOutId = goodsOutResult.insertId;

    // 2) Select eligible production rows (FIFO)
    // IMPORTANT: confirm your actual column name is pl.expiry_date
    const expiryClause = useNonExpiredOnly
      ? `AND (pl.expiry_date IS NULL OR pl.expiry_date >= ?)`
      : ``;

    const params = useNonExpiredOnly
      ? [recipe, cognito_id, goodsOutDate]
      : [recipe, cognito_id];

    const [productionRows] = await connection.execute(
      `
      SELECT pl.id, pl.batchRemaining, pl.batchCode, pl.expiry_date
        FROM production_log pl
       WHERE pl.recipe = ?
         AND pl.user_id = ?
         AND pl.batchRemaining > 0
         AND pl.deleted_at IS NULL
         ${expiryClause}
       ORDER BY pl.id ASC
      `,
      params
    );

    // 3) Hard-block if non-expired-only and not enough eligible stock
    if (useNonExpiredOnly) {
      const eligibleTotal = (productionRows || []).reduce((sum, r) => sum + Number(r.batchRemaining || 0), 0);

      if (eligibleTotal < remainingToDeduct) {
        await connection.rollback();
        return res.status(409).json({
          error: "Insufficient non-expired stock to fulfill this goods out.",
          code: "NON_EXPIRED_STOCK_INSUFFICIENT",
          recipe,
          goodsOutDate,
          requested: remainingToDeduct,
          availableNonExpired: eligibleTotal,
        });
      }
    }

    // 4) Deduct FIFO
    for (const row of productionRows) {
      if (remainingToDeduct <= 0) break;

      const deductAmount = Math.min(Number(row.batchRemaining || 0), remainingToDeduct);

      await connection.execute(
        `UPDATE production_log
            SET batchRemaining = batchRemaining - ?
          WHERE id = ?`,
        [deductAmount, row.id]
      );

      await connection.execute(
        `INSERT INTO goods_out_batches (goods_out_id, production_log_id, quantity_used)
         VALUES (?, ?, ?)`,
        [goodsOutId, row.id, deductAmount]
      );

      remainingToDeduct -= deductAmount;
    }

    // Keep your existing partial behaviour when NOT strict mode
    if (remainingToDeduct > 0) {
      console.warn(`Not enough eligible batches; ${remainingToDeduct} short (mode=${useNonExpiredOnly})`);
    }

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Goods out added; deducted from production_log rows.",
      allocationMode: useNonExpiredOnly ? "non-expired-only" : "fifo-any",
    });
  } catch (err) {
    await connection.rollback();
    console.error("Error processing /add-goods-out:", err);
    return res.status(500).json({
      error: "Internal Server Error",
      code: "SERVER_ERROR",
      details: err.message,
    });
  } finally {
    connection.release();
  }
});

app.post("/api/add-goods-out", async (req, res) => {
  const {
    date,
    recipe,
    stockAmount,
    recipients,
    cognito_id,
    avoidExpiredGoods, // read-only, not stored
  } = req.body;

  // Optional: keep CORS consistent with your batch endpoint
  res.setHeader("Access-Control-Allow-Origin", "https://master.d2fdrxobxyr2je.amplifyapp.com");
  res.setHeader("Access-Control-Allow-Credentials", "true");

  const missing = [];
  if (!date) missing.push("date");
  if (!recipe) missing.push("recipe");
  if (stockAmount === undefined || stockAmount === null || stockAmount === "") missing.push("stockAmount");
  if (!recipients) missing.push("recipients");
  if (!cognito_id) missing.push("cognito_id");

  if (missing.length) {
    return res.status(400).json({
      error: "All fields are required",
      code: "VALIDATION_ERROR",
      missing,
    });
  }

  const goodsOutDate = String(date).slice(0, 10);
  const useNonExpiredOnly = !!avoidExpiredGoods;

  const connection = await db.promise().getConnection();
  try {
    await connection.beginTransaction();

    // 0) Ensure recipe exists for this user
    const [recipeRows] = await connection.execute(
      `SELECT units_per_batch
         FROM recipes
        WHERE recipe_name = ?
          AND user_id = ?
        LIMIT 1`,
      [recipe, cognito_id]
    );

    if (!Array.isArray(recipeRows) || recipeRows.length === 0) {
      await connection.rollback();
      return res.status(400).json({
        error: `Recipe '${recipe}' not found for this user`,
        code: "RECIPE_NOT_FOUND",
        recipe,
      });
    }

    // NOTE: you currently treat stockAmount as "batches"
    const batchesToDeduct = Math.ceil(Number(stockAmount));
    if (!Number.isFinite(batchesToDeduct) || batchesToDeduct <= 0) {
      await connection.rollback();
      return res.status(400).json({
        error: "stockAmount must be a positive number",
        code: "VALIDATION_ERROR",
        field: "stockAmount",
      });
    }

    let remainingToDeduct = batchesToDeduct;

    // 1) Insert goods_out record
    const [goodsOutResult] = await connection.execute(
      `INSERT INTO goods_out (date, recipe, stockAmount, recipients, user_id)
       VALUES (?, ?, ?, ?, ?)`,
      [goodsOutDate, recipe, stockAmount, recipients, cognito_id]
    );
    const goodsOutId = goodsOutResult.insertId;

    // 2) Select eligible production rows (FIFO)
    // IMPORTANT: confirm your actual column name is pl.expiry_date
    const expiryClause = useNonExpiredOnly
      ? `AND (pl.expiry_date IS NULL OR pl.expiry_date >= ?)`
      : ``;

    const params = useNonExpiredOnly
      ? [recipe, cognito_id, goodsOutDate]
      : [recipe, cognito_id];

    const [productionRows] = await connection.execute(
      `
      SELECT pl.id, pl.batchRemaining, pl.batchCode, pl.expiry_date
        FROM production_log pl
       WHERE pl.recipe = ?
         AND pl.user_id = ?
         AND pl.batchRemaining > 0
         AND pl.deleted_at IS NULL
         ${expiryClause}
       ORDER BY pl.id ASC
      `,
      params
    );

    // 3) Hard-block if non-expired-only and not enough eligible stock
    if (useNonExpiredOnly) {
      const eligibleTotal = (productionRows || []).reduce((sum, r) => sum + Number(r.batchRemaining || 0), 0);

      if (eligibleTotal < remainingToDeduct) {
        await connection.rollback();
        return res.status(409).json({
          error: "Insufficient non-expired stock to fulfill this goods out.",
          code: "NON_EXPIRED_STOCK_INSUFFICIENT",
          recipe,
          goodsOutDate,
          requested: remainingToDeduct,
          availableNonExpired: eligibleTotal,
        });
      }
    }

    // 4) Deduct FIFO
    for (const row of productionRows) {
      if (remainingToDeduct <= 0) break;

      const deductAmount = Math.min(Number(row.batchRemaining || 0), remainingToDeduct);

      await connection.execute(
        `UPDATE production_log
            SET batchRemaining = batchRemaining - ?
          WHERE id = ?`,
        [deductAmount, row.id]
      );

      await connection.execute(
        `INSERT INTO goods_out_batches (goods_out_id, production_log_id, quantity_used)
         VALUES (?, ?, ?)`,
        [goodsOutId, row.id, deductAmount]
      );

      remainingToDeduct -= deductAmount;
    }

    // Keep your existing partial behaviour when NOT strict mode
    if (remainingToDeduct > 0) {
      console.warn(`Not enough eligible batches; ${remainingToDeduct} short (mode=${useNonExpiredOnly})`);
    }

    await connection.commit();

    return res.status(200).json({
      success: true,
      message: "Goods out added; deducted from production_log rows.",
      allocationMode: useNonExpiredOnly ? "non-expired-only" : "fifo-any",
    });
  } catch (err) {
    await connection.rollback();
    console.error("Error processing /add-goods-out:", err);
    return res.status(500).json({
      error: "Internal Server Error",
      code: "SERVER_ERROR",
      details: err.message,
    });
  } finally {
    connection.release();
  }
});

// =========================
// GET: goods-out-with-batches
// ✅ No schema changes needed; unchanged (no flag selected)
// =========================
app.get("/api/goods-out-with-batches", async (req, res) => {
  const { cognito_id } = req.query

  if (!cognito_id) {
    return res.status(400).json({ error: "cognito_id is required" })
  }

  try {
    const query = `
      SELECT 
        go.id AS goods_out_id,
        go.date,
        go.recipe,
        go.stockAmount,
        go.recipients,
        go.user_id,
        GROUP_CONCAT(pl.batchCode ORDER BY pl.id SEPARATOR ', ') AS batchCodesUsed,
        GROUP_CONCAT(gob.quantity_used ORDER BY pl.id SEPARATOR ', ') AS quantitiesUsed
      FROM goods_out go
      JOIN goods_out_batches gob ON go.id = gob.goods_out_id
      JOIN production_log pl ON gob.production_log_id = pl.id
      WHERE go.user_id = ?
      GROUP BY go.id
      ORDER BY go.date DESC
    `

    const [results] = await db.promise().query(query, [cognito_id])
    res.json(results)
  } catch (err) {
    console.error("Error fetching goods_out with batchCodes:", err)
    res.status(500).json({ error: "Database error" })
  }
})

// =========================
// GET: goods-out
// ✅ No schema changes needed; unchanged (no flag selected)
// =========================
app.get("/api/goods-out", async (req, res) => {
  const { cognito_id } = req.query

  if (!cognito_id) {
    return res.status(400).json({ error: "cognito_id is required" })
  }

  try {
    const query = `
      SELECT go.id, go.date, go.recipe, go.stockAmount, go.recipients,
             JSON_ARRAYAGG(pl.batchCode) AS batchcodes,
             JSON_ARRAYAGG(gob.quantity_used) AS quantitiesUsed
      FROM goods_out go
      JOIN goods_out_batches gob ON go.id = gob.goods_out_id
      JOIN production_log pl ON gob.production_log_id = pl.id
      WHERE go.user_id = ?
      GROUP BY go.id
      ORDER BY go.date DESC
    `
    
    const [results] = await db.promise().query(query, [cognito_id])
    res.json(results)
  } catch (err) {
    console.error("Database error:", err)
    res.status(500).json({ error: "Database error" })
  }
})

// HARD DELETE goods_out rows (and their links) for the signed-in user
app.post("/api/goods-out/delete", async (req, res) => {
  let { ids, id, cognito_id } = req.body;

  // Normalize ids to an array of integers
  if (!Array.isArray(ids)) ids = typeof id !== "undefined" ? [id] : [];
  ids = (ids || []).map((x) => Number(x)).filter((x) => Number.isInteger(x) && x > 0);

  if (!cognito_id || ids.length === 0) {
    return res.status(400).json({ error: "cognito_id and at least one numeric id are required" });
  }

  const placeholders = ids.map(() => "?").join(", ");

  // If you have ON DELETE CASCADE from goods_out -> goods_out_batches you can skip the first DELETE.
  // This version works even without CASCADE by manually removing child rows first.
  const conn = await db.promise().getConnection();
  try {
    await conn.beginTransaction();

    // 1) Delete join rows for only the caller's rows
    const delJoinSql = `
      DELETE gob
        FROM goods_out_batches AS gob
        JOIN goods_out AS go ON gob.goods_out_id = go.id
       WHERE go.id IN (${placeholders})
         AND go.user_id = ?`;
    const [delJoinRes] = await conn.query(delJoinSql, [...ids, cognito_id]);

    // 2) Delete goods_out rows themselves (scoped to user)
    const delSql = `
      DELETE FROM goods_out
       WHERE id IN (${placeholders})
         AND user_id = ?`;
    const [delRes] = await conn.query(delSql, [...ids, cognito_id]);

    await conn.commit();
    return res.json({
      message: "Goods out rows hard-deleted",
      requested: ids.length,
      deleted: delRes.affectedRows,
      deletedJoinRows: delJoinRes.affectedRows || 0,
    });
  } catch (err) {
    await conn.rollback();
    console.error("[/api/goods-out/delete] Failed:", err);
    return res.status(500).json({ error: "Failed to hard-delete goods out rows" });
  } finally {
    conn.release();
  }
});

app.get('/dev/health', (req, res) => {
  db.getConnection((err, conn) => {
    if (err) {
      res.status(500).json({ db: "DOWN", error: err.message });
    } else {
      conn.release();
      res.json({ db: "OK" });
    }
  });
});

// ─── Update a goods_in row ─────────────────────────────────────────────────────
app.put("/api/goods-in/:barCode", async (req, res) => {
  const { barCode } = req.params;
  const {
    date,
    ingredient,
    stockReceived,
    stockRemaining,
    unit,
    expiryDate,
    temperature,
    cognito_id
  } = req.body;

  // Basic validation
  if (
    !barCode ||
    !cognito_id ||
    !date ||
    !ingredient ||
    stockReceived  == null ||
    stockRemaining == null ||
    !unit ||
    !expiryDate    ||
    temperature    == null
  ) {
    return res.status(400).json({
      error: "barCode, cognito_id and all fields (date, ingredient, stockReceived, stockRemaining, unit, expiryDate, temperature) are required"
    });
  }

  try {
    const [result] = await db
      .promise()
      .execute(
        `UPDATE goods_in
            SET date           = ?,
                ingredient     = ?,
                stockReceived  = ?,
                stockRemaining = ?,
                unit           = ?,
                expiryDate     = ?,
                temperature    = ?
          WHERE barCode = ?
            AND user_id = ?`,
        [
          date,
          ingredient,
          stockReceived,
          stockRemaining,
          unit,
          expiryDate,
          temperature,
          barCode,
          cognito_id
        ]
      );

    if (result.affectedRows === 0) {
      return res
        .status(404)
        .json({ error: "No matching goods_in row found for that barCode/user" });
    }

    // Optionally: fetch and return the updated row
    const [[updatedRow]] = await db
      .promise()
      .query(
        `SELECT * FROM goods_in WHERE barCode = ? AND user_id = ?`,
        [barCode, cognito_id]
      );

    res.json({ success: true, updated: updatedRow });
  } catch (err) {
    console.error("Failed to update goods_in row:", err);
    res.status(500).json({
      error: "Database error updating goods_in row",
      details: err.message
    });
  }
});



// -----------------MRP-------------------------------------------------------------------------

app.get("/api/employees/list", async (req, res) => {
  try {
    const { cognito_id } = req.query;
    if (!cognito_id) {
      return res.status(400).json({ error: "cognito_id is required" });
    }

    const [rows] = await db.promise().query(
      `
      SELECT
        id,
        cognito_id,
        full_name,
        short_name,
        email,
        phone,
        title,
        employment_type,
        status,
        DATE_FORMAT(start_date, '%Y-%m-%d')      AS start_date,
        DATE_FORMAT(probation_end, '%Y-%m-%d')   AS probation_end,
        pay_type,
        hourly_rate,
        notes
      FROM employees
      WHERE cognito_id = ?
      ORDER BY full_name ASC, id ASC
      `,
      [cognito_id]
    );

    return res.json(rows);
  } catch (err) {
    console.error("[GET /api/employees/list] error:", err);
    return res.status(500).json({
      error: "Failed to fetch employees.",
      message: err.message,
    });
  }
});

// CREATE EMPLOYEE
app.post("/api/employees/create", async (req, res) => {
  try {
    const {
      cognito_id,
      full_name,
      short_name,
      email,
      phone,
      title,
      employment_type,
      status,
      start_date,
      probation_end,
      pay_type,
      hourly_rate,
      notes,
    } = req.body || {};

    if (!cognito_id || !full_name) {
      return res
        .status(400)
        .json({ error: "cognito_id and full_name are required" });
    }

    const [result] = await db.promise().query(
      `
      INSERT INTO employees (
        cognito_id,
        full_name,
        short_name,
        email,
        phone,
        title,
        employment_type,
        status,
        start_date,
        probation_end,
        pay_type,
        hourly_rate,
        notes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        cognito_id,
        full_name,
        short_name || null,
        email || null,
        phone || null,
        title || null,
        employment_type || null,
        status || "active",
        start_date || null,
        probation_end || null,
        pay_type || null,
        hourly_rate === null || hourly_rate === undefined ? null : hourly_rate,
        notes || null,
      ]
    );

    const insertedId = result.insertId;

    const [rows] = await db.promise().query(
      `
      SELECT
        id,
        cognito_id,
        full_name,
        short_name,
        email,
        phone,
        title,
        employment_type,
        status,
        DATE_FORMAT(start_date, '%Y-%m-%d')      AS start_date,
        DATE_FORMAT(probation_end, '%Y-%m-%d')   AS probation_end,
        pay_type,
        hourly_rate,
        notes
      FROM employees
      WHERE id = ?
      `,
      [insertedId]
    );

    return res.status(201).json(rows[0] || null);
  } catch (err) {
    console.error("[POST /api/employees/create] error:", err);
    return res.status(500).json({
      error: "Failed to create employee.",
      message: err.message,
    });
  }
});

// UPDATE EMPLOYEE
app.put("/api/employees/:id/update", async (req, res) => {
  try {
    const { id } = req.params;
    const {
      cognito_id,
      full_name,
      short_name,
      email,
      phone,
      title,
      employment_type,
      status,
      start_date,
      probation_end,
      pay_type,
      hourly_rate,
      notes,
    } = req.body || {};

    if (!cognito_id) {
      return res
        .status(400)
        .json({ error: "cognito_id is required for update" });
    }

    const [result] = await db.promise().query(
      `
      UPDATE employees
      SET
        full_name       = ?,
        short_name      = ?,
        email           = ?,
        phone           = ?,
        title           = ?,
        employment_type = ?,
        status          = ?,
        start_date      = ?,
        probation_end   = ?,
        pay_type        = ?,
        hourly_rate     = ?,
        notes           = ?
      WHERE id = ?
        AND cognito_id = ?
      `,
      [
        full_name || null,
        short_name || null,
        email || null,
        phone || null,
        title || null,
        employment_type || null,
        status || "active",
        start_date || null,
        probation_end || null,
        pay_type || null,
        hourly_rate === null || hourly_rate === undefined ? null : hourly_rate,
        notes || null,
        id,
        cognito_id,
      ]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        error: "Employee not found or not owned by this tenant.",
      });
    }

    const [rows] = await db.promise().query(
      `
      SELECT
        id,
        cognito_id,
        full_name,
        short_name,
        email,
        phone,
        title,
        employment_type,
        status,
        DATE_FORMAT(start_date, '%Y-%m-%d')      AS start_date,
        DATE_FORMAT(probation_end, '%Y-%m-%d')   AS probation_end,
        pay_type,
        hourly_rate,
        notes
      FROM employees
      WHERE id = ?
      `,
      [id]
    );

    return res.json(rows[0] || null);
  } catch (err) {
    console.error("[PUT /api/employees/:id/update] error:", err);
    return res.status(500).json({
      error: "Failed to update employee.",
      message: err.message,
    });
  }
});

// DELETE EMPLOYEE
app.delete("/api/employees/:id/delete", async (req, res) => {
  try {
    const { id } = req.params;
    const { cognito_id } = req.query;

    if (!cognito_id) {
      return res
        .status(400)
        .json({ error: "cognito_id is required for delete" });
    }

    const [result] = await db.promise().query(
      `
      DELETE FROM employees
      WHERE id = ?
        AND cognito_id = ?
      `,
      [id, cognito_id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        error: "Employee not found or not owned by this tenant.",
      });
    }

    return res.json({ deleted: true, id });
  } catch (err) {
    console.error("[DELETE /api/employees/:id/delete] error:", err);
    return res.status(500).json({
      error: "Failed to delete employee.",
      message: err.message,
    });
  }
});

const roleId = null;

function httpError(statusCode, message) {
  const e = new Error(message);
  e.statusCode = statusCode;
  return e;
}

function assertYYYYMMDD(s) {
  if (typeof s !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(s)) {
    throw httpError(400, "Invalid date format. Expected YYYY-MM-DD.");
  }
  return s;
}
function addDaysYYYYMMDD(yyyyMmDd, add) {
  const [y, m, d] = yyyyMmDd.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + Number(add || 0));
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}
function assertHHMM(s) {
  if (typeof s !== "string" || !/^\d{2}:\d{2}$/.test(s)) {
    throw httpError(400, "Invalid time format. Expected HH:MM.");
  }
  return s;
}

/* =========================================================
   GET WEEK: /roster/week?cognito_id=...&week_start=YYYY-MM-DD
   ========================================================= */
app.get("/api/roster/week", async (req, res, next) => {
  try {
    const cognitoId = String(req.query.cognito_id || "").trim();
    const weekStart = assertYYYYMMDD(String(req.query.week_start || "").trim());
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const weekEnd = addDaysYYYYMMDD(weekStart, 6);

    const rows = await withConn(async (conn) => {
      const [r] = await conn.execute(
        `
        SELECT
          rsa.id AS assignment_id,
          rsa.employee_id AS employee_id,
          rsa.status AS assignment_status,
          rsa.comment AS assignment_comment,

          rs.id AS roster_shift_id,
          rs.date AS shift_date,
          rs.area AS area,
          rs.status AS roster_status,
          rs.notes AS roster_notes,

          st.id AS shift_template_id,
          st.name AS template_name,
          st.start_time AS start_time,
          st.end_time AS end_time,

          rrole.id AS role_id,
          rrole.code AS role_code,
          rrole.name AS role_name

        FROM roster_shifts rs
        JOIN employee_shift_assignments rsa ON rsa.roster_shift_id = rs.id
        LEFT JOIN shift_templates st ON st.id = rs.shift_template_id
        LEFT JOIN roles rrole ON rrole.id = st.role_id

        WHERE rs.cognito_id = ?
          AND rs.date BETWEEN ? AND ?
        ORDER BY rs.date ASC, st.start_time ASC, rsa.employee_id ASC
        `,
        [cognitoId, weekStart, weekEnd]
      );
      return r;
    });

    res.json({ cognito_id: cognitoId, week_start: weekStart, week_end: weekEnd, rows });
  } catch (err) {
    next(err);
  }
});

/* =========================================================
   POST SHIFT: /api/roster/shift
   Body: { cognito_id,date,employee_id,role_key,role_name,area,start,end,status,comment }
   ========================================================= */
app.post("/api/roster/shift", async (req, res, next) => {
  try {
    const body = req.body || {};
    const cognitoId = String(body.cognito_id || "").trim();
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const date = assertYYYYMMDD(String(body.date || "").trim());
    const employeeId = String(body.employee_id || "").trim();
    if (!employeeId || employeeId.length !== 36) throw httpError(400, "Invalid employee_id (expected UUID)");

    const roleKey = String(body.role_key || "").trim();
    if (!roleKey) throw httpError(400, "Missing role_key");

    const roleName = String(body.role_name || roleKey).trim();
    const area = String(body.area || "default").trim();
    const start = assertHHMM(String(body.start || "").trim());
    const end = assertHHMM(String(body.end || "").trim());

    const assignmentStatus = String(body.status || "planned").trim();
    const comment = body.comment == null ? null : String(body.comment);

    const out = await withConn(async (conn) => {
      await conn.beginTransaction();
      try {
        // 0) Optional: resolve a real roles.id (UUID) if it exists; else NULL (safe)
        let roleId = null;
        {
          const [roleRows] = await conn.execute(
            `
            SELECT id
            FROM roles
            WHERE cognito_id = ?
              AND (
                code = ?
                OR name = ?
              )
            LIMIT 1
            `,
            [cognitoId, roleKey, roleName]
          );
          roleId = roleRows?.[0]?.id || null;
        }

        // 1) Find or create shift_template (UUID default generated by DB)
        let shiftTemplateId = null;

        const [tplRows] = await conn.execute(
          `
          SELECT id
          FROM shift_templates
          WHERE cognito_id = ?
            AND name = ?
            AND COALESCE(area,'') = COALESCE(?, '')
            AND start_time = ?
            AND end_time = ?
          LIMIT 1
          `,
          [cognitoId, roleName, area, start, end]
        );

        shiftTemplateId = tplRows?.[0]?.id || null;

        if (!shiftTemplateId) {
          await conn.execute(
            `
            INSERT INTO shift_templates
              (cognito_id, name, role_id, area, start_time, end_time, default_headcount, notes)
            VALUES
              (?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
              cognitoId,
              roleName,
              roleId, // ✅ NULL if not found (won't break FK)
              area,
              start,
              end,
              1,
              JSON.stringify({ role_key: roleKey }),
            ]
          );

          const [tpl2] = await conn.execute(
            `
            SELECT id
            FROM shift_templates
            WHERE cognito_id = ?
              AND name = ?
              AND COALESCE(area,'') = COALESCE(?, '')
              AND start_time = ?
              AND end_time = ?
            ORDER BY created_at DESC
            LIMIT 1
            `,
            [cognitoId, roleName, area, start, end]
          );
          shiftTemplateId = tpl2?.[0]?.id || null;
        }

        if (!shiftTemplateId) throw httpError(500, "Failed to resolve shift_template_id");

        // 2) Upsert roster_shifts (unique uq_roster_shift: cognito_id,date,shift_template_id)
        await conn.execute(
          `
          INSERT INTO roster_shifts
            (cognito_id, date, shift_template_id, area, status, notes)
          VALUES
            (?, ?, ?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            area = VALUES(area),
            status = VALUES(status),
            notes = VALUES(notes),
            updated_at = CURRENT_TIMESTAMP
          `,
          [cognitoId, date, shiftTemplateId, area, "planned", null]
        );

        const [rsRows] = await conn.execute(
          `
          SELECT id
          FROM roster_shifts
          WHERE cognito_id = ? AND date = ? AND shift_template_id = ?
          LIMIT 1
          `,
          [cognitoId, date, shiftTemplateId]
        );

        const rosterShiftId = rsRows?.[0]?.id || null;
        if (!rosterShiftId) throw httpError(500, "Failed to resolve roster_shift_id");

        // 3) Upsert employee_shift_assignments (unique uq_assignment)
        await conn.execute(
          `
          INSERT INTO employee_shift_assignments
            (roster_shift_id, employee_id, status, comment)
          VALUES
            (?, ?, ?, ?)
          ON DUPLICATE KEY UPDATE
            status = VALUES(status),
            comment = VALUES(comment),
            updated_at = CURRENT_TIMESTAMP
          `,
          [rosterShiftId, employeeId, assignmentStatus, comment]
        );

        const [aRows] = await conn.execute(
          `
          SELECT id
          FROM employee_shift_assignments
          WHERE roster_shift_id = ? AND employee_id = ?
          LIMIT 1
          `,
          [rosterShiftId, employeeId]
        );

        const assignmentId = aRows?.[0]?.id || null;
        if (!assignmentId) throw httpError(500, "Failed to resolve assignment_id");

        await conn.commit();

        return {
          assignment_id: assignmentId,
          roster_shift_id: rosterShiftId,
          shift_template_id: shiftTemplateId,
          date,
          employee_id: employeeId,
          role_key: roleKey,
          role_name: roleName,
          area,
          start,
          end,
          status: assignmentStatus,
          comment,
        };
      } catch (e) {
        await conn.rollback();
        throw e;
      }
    });

    res.status(201).json(out);
  } catch (err) {
    next(err);
  }
});

/* =========================================================
   PUT ASSIGNMENT: /api/roster/assignment/:id
   Body: { cognito_id, status?, comment? }
   ========================================================= */
app.put("/api/roster/assignment/:id", async (req, res, next) => {
  try {
    const assignmentId = String(req.params.id || "").trim();
    if (!assignmentId || assignmentId.length !== 36) throw httpError(400, "Invalid assignment id (expected UUID)");

    const cognitoId = String(req.body?.cognito_id || "").trim();
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const status = req.body?.status == null ? null : String(req.body.status);
    const comment = req.body?.comment == null ? null : String(req.body.comment);

    const updated = await withConn(async (conn) => {
      // ownership check via roster_shifts
      const [ownRows] = await conn.execute(
        `
        SELECT rsa.id
        FROM employee_shift_assignments rsa
        JOIN roster_shifts rs ON rs.id = rsa.roster_shift_id
        WHERE rsa.id = ? AND rs.cognito_id = ?
        LIMIT 1
        `,
        [assignmentId, cognitoId]
      );
      if (!ownRows.length) throw httpError(404, "Assignment not found");

      await conn.execute(
        `
        UPDATE employee_shift_assignments
        SET
          status = COALESCE(?, status),
          comment = COALESCE(?, comment),
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        `,
        [status, comment, assignmentId]
      );

      const [rows] = await conn.execute(
        `SELECT id, roster_shift_id, employee_id, status, comment, updated_at
         FROM employee_shift_assignments
         WHERE id = ?`,
        [assignmentId]
      );
      return rows[0] || null;
    });

    res.json(updated);
  } catch (err) {
    next(err);
  }
});

/* =========================================================
   DELETE ASSIGNMENT: /api/roster/assignment/:id?cognito_id=...
   ========================================================= */
app.delete("/api/roster/assignment/:id", async (req, res, next) => {
  try {
    const assignmentId = String(req.params.id || "").trim();
    if (!assignmentId || assignmentId.length !== 36) throw httpError(400, "Invalid assignment id (expected UUID)");

    const cognitoId = String(req.query.cognito_id || "").trim();
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    await withConn(async (conn) => {
      await conn.beginTransaction();
      try {
        const [rows] = await conn.execute(
          `
          SELECT rsa.roster_shift_id
          FROM employee_shift_assignments rsa
          JOIN roster_shifts rs ON rs.id = rsa.roster_shift_id
          WHERE rsa.id = ? AND rs.cognito_id = ?
          LIMIT 1
          `,
          [assignmentId, cognitoId]
        );
        if (!rows.length) throw httpError(404, "Assignment not found");

        const rosterShiftId = rows[0].roster_shift_id;

        await conn.execute(`DELETE FROM employee_shift_assignments WHERE id = ?`, [assignmentId]);

        const [countRows] = await conn.execute(
          `SELECT COUNT(*) AS c FROM employee_shift_assignments WHERE roster_shift_id = ?`,
          [rosterShiftId]
        );

        const c = Number(countRows?.[0]?.c || 0);
        if (c === 0) {
          await conn.execute(`DELETE FROM roster_shifts WHERE id = ?`, [rosterShiftId]);
        }

        await conn.commit();
      } catch (e) {
        await conn.rollback();
        throw e;
      }
    });

    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

function asBool01(v, fallback = 1) {
  if (v === true || v === 1 || v === "1" || v === "true") return 1;
  if (v === false || v === 0 || v === "0" || v === "false") return 0;
  return fallback;
}

function cleanStr(v, max = 255) {
  if (v == null) return null;
  const s = String(v).trim();
  if (!s) return null;
  return s.slice(0, max);
}

/**
 * GET /roles/list?cognito_id=...
 * Returns roles for that tenant (cognito_id)
 */
app.get("/api/roles/list", async (req, res, next) => {
  try {
    const cognitoId = cleanStr(req.query.cognito_id);
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const [rows] = await pool.execute(
      `
      SELECT id, cognito_id, name, code, description, is_production_role, created_at, updated_at
      FROM roles
      WHERE cognito_id = ?
      ORDER BY is_production_role DESC, name ASC
      `,
      [cognitoId]
    );

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

/**
 * POST /roles/create
 * body: { cognito_id, name, code?, description?, is_production_role? }
 */
app.post("/api/roles/create", async (req, res, next) => {
  try {
    const body = req.body || {};
    const cognitoId = cleanStr(body.cognito_id);
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const name = cleanStr(body.name, 100);
    if (!name) throw httpError(400, "Missing name");

    const code = cleanStr(body.code, 50);
    const description = cleanStr(body.description, 2000);
    const isProduction = asBool01(body.is_production_role, 1);

    await pool.execute(
      `
      INSERT INTO roles (cognito_id, name, code, description, is_production_role)
      VALUES (?, ?, ?, ?, ?)
      `,
      [cognitoId, name, code, description, isProduction]
    );

    // return the newly created role (latest by created_at for this tenant/name)
    const [rows] = await pool.execute(
      `
      SELECT id, cognito_id, name, code, description, is_production_role, created_at, updated_at
      FROM roles
      WHERE cognito_id = ? AND name = ?
      ORDER BY created_at DESC
      LIMIT 1
      `,
      [cognitoId, name]
    );

    res.status(201).json(rows[0] || { ok: true });
  } catch (err) {
    next(err);
  }
});

/**
 * PUT /roles/update/:id
 * body: { cognito_id, name?, code?, description?, is_production_role? }
 */
app.put("/api/roles/update/:id", async (req, res, next) => {
  try {
    const roleId = cleanStr(req.params.id, 36);
    if (!roleId) throw httpError(400, "Missing role id");

    const body = req.body || {};
    const cognitoId = cleanStr(body.cognito_id);
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    // ownership check
    const [own] = await pool.execute(
      `SELECT id FROM roles WHERE id = ? AND cognito_id = ? LIMIT 1`,
      [roleId, cognitoId]
    );
    if (!own.length) throw httpError(404, "Role not found");

    const name = body.name == null ? null : cleanStr(body.name, 100);
    const code = body.code == null ? null : cleanStr(body.code, 50);
    const description = body.description == null ? null : cleanStr(body.description, 2000);
    const isProduction =
      body.is_production_role == null ? null : asBool01(body.is_production_role, 1);

    await pool.execute(
      `
      UPDATE roles
      SET
        name = COALESCE(?, name),
        code = COALESCE(?, code),
        description = COALESCE(?, description),
        is_production_role = COALESCE(?, is_production_role),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ? AND cognito_id = ?
      `,
      [name, code, description, isProduction, roleId, cognitoId]
    );

    const [rows] = await pool.execute(
      `
      SELECT id, cognito_id, name, code, description, is_production_role, created_at, updated_at
      FROM roles
      WHERE id = ? AND cognito_id = ?
      LIMIT 1
      `,
      [roleId, cognitoId]
    );

    res.json(rows[0] || { ok: true });
  } catch (err) {
    next(err);
  }
});

/**
 * DELETE /roles/delete/:id?cognito_id=...
 */
app.delete("/api/roles/delete/:id", async (req, res, next) => {
  try {
    const roleId = cleanStr(req.params.id, 36);
    if (!roleId) throw httpError(400, "Missing role id");

    const cognitoId = cleanStr(req.query.cognito_id);
    if (!cognitoId) throw httpError(400, "Missing cognito_id");

    const [result] = await pool.execute(
      `DELETE FROM roles WHERE id = ? AND cognito_id = ?`,
      [roleId, cognitoId]
    );

    if (!result.affectedRows) throw httpError(404, "Role not found");
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

app.use((req, res) => {
  console.error('404 Not Found:', {
    method: req.method,
    url: req.originalUrl,
    headers: req.headers,
    ip: req.ip
  });
  res.status(404).json({ error: 'Not found' });
});

// ✅ Enhanced error handling middleware
app.use((err, req, res, next) => {
  const errorDetails = {
    message: err.message,
    stack: err.stack,
    type: err.type,
    status: err.status,
    request: {
      method: req.method,
      url: req.url,
      headers: req.headers,
      body: req.body,
      query: req.query
    },
    timestamp: new Date().toISOString()
  };

  console.error('SERVER ERROR:', JSON.stringify(errorDetails, null, 2));

  // Special handling for CORS errors
  if (err.message.includes('CORS')) {
    console.error('CORS ERROR DETAILS:', {
      origin: req.headers.origin,
      allowedOrigins: '*', // Update this in production
      method: req.method
    });
    
    return res.status(403).json({
      error: 'CORS Error',
      message: err.message,
      details: process.env.NODE_ENV === 'development' ? errorDetails : undefined
    });
  }

  res.status(err.status || 500).json({
    error: 'Internal server error',
    message: err.message,
    details: process.env.NODE_ENV === 'development' ? errorDetails : undefined
  });
});

module.exports.handler = serverless(app, {
  request: {
    parse: true,
    passThrough: true,
  },
});